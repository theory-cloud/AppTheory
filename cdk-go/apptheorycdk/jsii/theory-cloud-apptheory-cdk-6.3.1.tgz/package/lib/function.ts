import { Duration, RemovalPolicy, Token } from "aws-cdk-lib";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as codedeploy from "aws-cdk-lib/aws-codedeploy";
import * as iam from "aws-cdk-lib/aws-iam";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as logs from "aws-cdk-lib/aws-logs";
import { Construct } from "constructs";

/**
 * Traffic shifting mode for AppTheory-managed Lambda aliases.
 */
export enum AppTheoryLambdaTrafficShiftType {
  /**
   * Shift all traffic to the new version at once.
   */
  ALL_AT_ONCE = "ALL_AT_ONCE",

  /**
   * Shift one canary increment, wait, then shift the remaining traffic.
   */
  CANARY = "CANARY",

  /**
   * Shift traffic in equal linear increments.
   */
  LINEAR = "LINEAR",
}

/**
 * CodeDeploy deployment preferences for an AppTheory Lambda alias.
 */
export interface AppTheoryFunctionDeploymentOptions {
  /**
   * Traffic shifting mode.
   * @default AppTheoryLambdaTrafficShiftType.CANARY
   */
  readonly trafficShiftType?: AppTheoryLambdaTrafficShiftType;

  /**
   * Percentage shifted at each canary or linear increment.
   * @default 10
   */
  readonly percentage?: number;

  /**
   * Time between traffic shifts.
   * @default Duration.minutes(5) for canary, Duration.minutes(1) for linear
   */
  readonly interval?: Duration;

  /**
   * CloudWatch alarms that stop and roll back deployments.
   * @default []
   */
  readonly alarms?: cloudwatch.IAlarm[];

  /**
   * Lambda pre-traffic hook.
   * @default undefined
   */
  readonly preHook?: lambda.IFunction;

  /**
   * Lambda post-traffic hook.
   * @default undefined
   */
  readonly postHook?: lambda.IFunction;

  /**
   * CodeDeploy auto-rollback configuration.
   * @default CodeDeploy defaults
   */
  readonly autoRollback?: codedeploy.AutoRollbackConfig;
}

/**
 * Alias and provisioned-concurrency options for an AppTheory function.
 */
export interface AppTheoryFunctionAliasOptions {
  /**
   * Lambda alias name.
   * @default "live"
   */
  readonly name?: string;

  /**
   * Alias description.
   * @default undefined
   */
  readonly description?: string;

  /**
   * Provisioned concurrency configured on the alias.
   * @default undefined
   */
  readonly provisionedConcurrentExecutions?: number;

  /**
   * Optional CodeDeploy traffic shifting for this alias.
   * @default undefined
   */
  readonly deployment?: AppTheoryFunctionDeploymentOptions;
}

/**
 * Properties for an AppTheory-managed Lambda function.
 *
 * AppTheory overrides the inherited `logRemovalPolicy` default for log groups
 * it creates: they use `RemovalPolicy.RETAIN`, so deleting a stack preserves
 * the execution logs. Pass `RemovalPolicy.DESTROY` explicitly to opt back into
 * the destructive behavior. Combining an explicit `logRemovalPolicy` with a
 * caller-provided `logGroup` fails synthesis because caller-provided resources
 * own their removal policy.
 *
 * Both `logRetention` and `logRemovalPolicy` are deprecated upstream in favor
 * of `logGroup` (`@deprecated use logGroup instead` on the inherited Lambda L2
 * props). The migration is to create a `logs.LogGroup` with the desired
 * `retention` and `removalPolicy` and pass it as `logGroup`; AppTheory then
 * uses that group unchanged. An explicit `logGroup` wins over `logRetention`,
 * and combining it with `logRemovalPolicy` fails synthesis.
 *
 * jsii forbids re-declaring the inherited props, so the deprecation notice is
 * carried by the base Lambda L2 interface rather than restated here.
 */
export interface AppTheoryFunctionProps extends lambda.FunctionProps {
  /**
   * Stable physical name for the AppTheory-managed Lambda execution role.
   *
   * AppTheory preserves the Lambda L2's policies. Concrete names are synthesis-validated against IAM's `[\w+=,.@-]+` character set and 64-character limit.
   * Token-valued names are accepted and IAM validates the resolved value at deploy time, so an invalid resolved name fails deployment rather than synthesis.
   * This exemption keeps account-agnostic synthesis representable for the THE-2861 token-valued-input failure class. Do not combine this with the inherited `role`
   * prop; caller-provided roles own their physical name.
   *
   * @default undefined
   */
  readonly roleName?: string;

  /**
   * Optional AppTheory-managed Lambda alias.
   *
   * When set, the alias points at the function's current version and can also
   * carry provisioned concurrency and CodeDeploy traffic shifting.
   *
   * @default undefined
   */
  readonly alias?: AppTheoryFunctionAliasOptions;
}

export class AppTheoryFunction extends Construct {
  public readonly fn: lambda.Function;
  public readonly logGroup?: logs.ILogGroupRef;
  public readonly alias?: lambda.Alias;
  public readonly deploymentGroup?: codedeploy.LambdaDeploymentGroup;

  constructor(scope: Construct, id: string, props: AppTheoryFunctionProps) {
    super(scope, id);

    const { alias, roleName, ...inputLambdaProps } = props;
    const lambdaProps: lambda.FunctionProps = { ...inputLambdaProps };
    if (roleName !== undefined) {
      if (lambdaProps.role) {
        throw new Error(
          "AppTheoryFunction cannot honor props.roleName when props.role supplies the execution role; omit props.role or configure its name where that role is created",
        );
      }
    }
    const logRetention = lambdaProps.logRetention ?? logs.RetentionDays.ONE_MONTH;
    const requestedLogRemovalPolicy = lambdaProps.logRemovalPolicy;
    if (lambdaProps.logGroup && requestedLogRemovalPolicy !== undefined) {
      throw new Error(
        "AppTheoryFunction cannot honor props.logRemovalPolicy when props.logGroup supplies the log group; omit props.logRemovalPolicy or configure the removal policy where that log group is created",
      );
    }
    delete (lambdaProps as { logRetention?: logs.RetentionDays }).logRetention;
    delete (lambdaProps as { logRemovalPolicy?: unknown }).logRemovalPolicy;
    delete (lambdaProps as { logRetentionRetryOptions?: unknown }).logRetentionRetryOptions;
    delete (lambdaProps as { logRetentionRole?: unknown }).logRetentionRole;

    let boundLogGroup = lambdaProps.logGroup;
    if (!boundLogGroup && lambdaProps.functionName) {
      boundLogGroup = createManagedFunctionLogGroup(
        this,
        `/aws/lambda/${lambdaProps.functionName}`,
        logRetention,
        requestedLogRemovalPolicy ?? RemovalPolicy.RETAIN,
      );
    }

    this.fn = new lambda.Function(this, "Function", {
      ...lambdaProps,
      logGroup: boundLogGroup,
      architecture: lambdaProps.architecture ?? lambda.Architecture.ARM_64,
      tracing: lambdaProps.tracing ?? lambda.Tracing.ACTIVE,
      memorySize: lambdaProps.memorySize ?? 256,
      timeout: lambdaProps.timeout ?? Duration.seconds(10),
    });

    if (roleName !== undefined) {
      if (!Token.isUnresolved(roleName)) {
        if (!roleName.trim()) {
          throw new Error("AppTheoryFunction roleName must not be empty");
        }
        if (roleName.length > 64) {
          throw new Error("AppTheoryFunction roleName must not exceed 64 characters");
        }
        if (!/^[\w+=,.@-]+$/.test(roleName)) {
          throw new Error("AppTheoryFunction roleName must match [\\w+=,.@-]+");
        }
      }
      const roleResource = this.fn.role?.node.defaultChild;
      if (!(roleResource instanceof iam.CfnRole)) {
        throw new Error(
          `AppTheoryFunction cannot apply the required stable roleName ${JSON.stringify(roleName)} because the Lambda execution role's default child is not an AWS::IAM::Role`,
        );
      }
      roleResource.addPropertyOverride("RoleName", roleName);
    }

    if (boundLogGroup) {
      (this as { logGroup?: logs.ILogGroupRef }).logGroup = boundLogGroup;
    } else {
      // Anonymous Lambda physical names are generated by CloudFormation. Keep
      // the finite-retention log group, but require callers that need a
      // fail-safe existing-stack upgrade/adoption path to pass logGroup or a
      // concrete functionName so the Lambda L2 can bind the group up front.
      const logGroup = createManagedFunctionLogGroup(
        this,
        `/aws/lambda/${this.fn.functionName}`,
        logRetention,
        requestedLogRemovalPolicy ?? RemovalPolicy.RETAIN,
      );
      (this as { logGroup?: logs.ILogGroupRef }).logGroup = logGroup;
    }

    if (alias) {
      this.configureAlias(alias);
    }
  }

  private configureAlias(options: AppTheoryFunctionAliasOptions): void {
    const aliasName = String(options.name ?? "live").trim();
    if (!aliasName) {
      throw new Error("AppTheoryFunction alias.name must not be empty");
    }

    const alias = new lambda.Alias(this, "Alias", {
      aliasName,
      version: this.fn.currentVersion,
      description: options.description,
      provisionedConcurrentExecutions: options.provisionedConcurrentExecutions,
    });
    (this as { alias?: lambda.Alias }).alias = alias;

    if (options.deployment) {
      const deploymentGroup = new codedeploy.LambdaDeploymentGroup(this, "DeploymentGroup", {
        alias,
        deploymentConfig: deploymentConfigFor(this, options.deployment),
        alarms: options.deployment.alarms,
        preHook: options.deployment.preHook,
        postHook: options.deployment.postHook,
        autoRollback: options.deployment.autoRollback,
      });
      (this as { deploymentGroup?: codedeploy.LambdaDeploymentGroup }).deploymentGroup = deploymentGroup;
    }
  }
}

function createManagedFunctionLogGroup(
  scope: Construct,
  logGroupName: string,
  retention: logs.RetentionDays,
  removalPolicy: RemovalPolicy,
): logs.LogGroup {
  if (removalPolicy === RemovalPolicy.SNAPSHOT) {
    throw new Error(
      "AppTheoryFunction cannot apply RemovalPolicy.SNAPSHOT because AWS::Logs::LogGroup does not support snapshot removal policies",
    );
  }

  const logGroup = new logs.LogGroup(scope, "LogGroup", {
    logGroupName,
    retention,
  });

  const logGroupResource = logGroup.node.defaultChild;
  if (!(logGroupResource instanceof logs.CfnLogGroup)) {
    throw new Error(
      `AppTheoryFunction cannot apply logRemovalPolicy ${JSON.stringify(removalPolicy)} because the AppTheory-managed log group's default child is not an AWS::Logs::LogGroup`,
    );
  }
  logGroupResource.applyRemovalPolicy(removalPolicy);

  return logGroup;
}

function deploymentConfigFor(scope: Construct, options: AppTheoryFunctionDeploymentOptions): codedeploy.ILambdaDeploymentConfig {
  const type = options.trafficShiftType ?? AppTheoryLambdaTrafficShiftType.CANARY;
  switch (type) {
    case AppTheoryLambdaTrafficShiftType.ALL_AT_ONCE:
      return codedeploy.LambdaDeploymentConfig.ALL_AT_ONCE;
    case AppTheoryLambdaTrafficShiftType.LINEAR:
      return new codedeploy.LambdaDeploymentConfig(scope, "LinearDeploymentConfig", {
        trafficRouting: codedeploy.TrafficRouting.timeBasedLinear({
          percentage: normalizedPercentage(options.percentage),
          interval: options.interval ?? Duration.minutes(1),
        }),
      });
    case AppTheoryLambdaTrafficShiftType.CANARY:
      return new codedeploy.LambdaDeploymentConfig(scope, "CanaryDeploymentConfig", {
        trafficRouting: codedeploy.TrafficRouting.timeBasedCanary({
          percentage: normalizedPercentage(options.percentage),
          interval: options.interval ?? Duration.minutes(5),
        }),
      });
    default:
      throw new Error(`AppTheoryFunction unsupported deployment type: ${String(type)}`);
  }
}

function normalizedPercentage(input?: number): number {
  const value = input ?? 10;
  if (!Number.isFinite(value) || value <= 0 || value >= 100) {
    throw new Error("AppTheoryFunction deployment percentage must be greater than 0 and less than 100");
  }
  return value;
}

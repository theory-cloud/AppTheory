import { Duration } from "aws-cdk-lib";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as codedeploy from "aws-cdk-lib/aws-codedeploy";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as logs from "aws-cdk-lib/aws-logs";
import { Construct } from "constructs";
/**
 * Traffic shifting mode for AppTheory-managed Lambda aliases.
 */
export declare enum AppTheoryLambdaTrafficShiftType {
    /**
     * Shift all traffic to the new version at once.
     */
    ALL_AT_ONCE = "ALL_AT_ONCE",
    /**
     * Shift one canary increment, wait, then shift the remaining traffic.
     */
    CANARY = "CANARY",
    /**
     * Shift traffic in equal linear increments.
     */
    LINEAR = "LINEAR"
}
/**
 * CodeDeploy deployment preferences for an AppTheory Lambda alias.
 */
export interface AppTheoryFunctionDeploymentOptions {
    /**
     * Traffic shifting mode.
     * @default AppTheoryLambdaTrafficShiftType.CANARY
     */
    readonly trafficShiftType?: AppTheoryLambdaTrafficShiftType;
    /**
     * Percentage shifted at each canary or linear increment.
     * @default 10
     */
    readonly percentage?: number;
    /**
     * Time between traffic shifts.
     * @default Duration.minutes(5) for canary, Duration.minutes(1) for linear
     */
    readonly interval?: Duration;
    /**
     * CloudWatch alarms that stop and roll back deployments.
     * @default []
     */
    readonly alarms?: cloudwatch.IAlarm[];
    /**
     * Lambda pre-traffic hook.
     * @default undefined
     */
    readonly preHook?: lambda.IFunction;
    /**
     * Lambda post-traffic hook.
     * @default undefined
     */
    readonly postHook?: lambda.IFunction;
    /**
     * CodeDeploy auto-rollback configuration.
     * @default CodeDeploy defaults
     */
    readonly autoRollback?: codedeploy.AutoRollbackConfig;
}
/**
 * Alias and provisioned-concurrency options for an AppTheory function.
 */
export interface AppTheoryFunctionAliasOptions {
    /**
     * Lambda alias name.
     * @default "live"
     */
    readonly name?: string;
    /**
     * Alias description.
     * @default undefined
     */
    readonly description?: string;
    /**
     * Provisioned concurrency configured on the alias.
     * @default undefined
     */
    readonly provisionedConcurrentExecutions?: number;
    /**
     * Optional CodeDeploy traffic shifting for this alias.
     * @default undefined
     */
    readonly deployment?: AppTheoryFunctionDeploymentOptions;
}
/**
 * Properties for an AppTheory-managed Lambda function.
 *
 * AppTheory overrides the inherited `logRemovalPolicy` default for log groups
 * it creates: they use `RemovalPolicy.RETAIN`, so deleting a stack preserves
 * the execution logs. Pass `RemovalPolicy.DESTROY` explicitly to opt back into
 * the destructive behavior. Combining an explicit `logRemovalPolicy` with a
 * caller-provided `logGroup` fails synthesis because caller-provided resources
 * own their removal policy.
 *
 * Both `logRetention` and `logRemovalPolicy` are deprecated upstream in favor
 * of `logGroup` (`@deprecated use logGroup instead` on the inherited Lambda L2
 * props). The migration is to create a `logs.LogGroup` with the desired
 * `retention` and `removalPolicy` and pass it as `logGroup`; AppTheory then
 * uses that group unchanged. An explicit `logGroup` wins over `logRetention`,
 * and combining it with `logRemovalPolicy` fails synthesis.
 *
 * jsii forbids re-declaring the inherited props, so the deprecation notice is
 * carried by the base Lambda L2 interface rather than restated here.
 */
export interface AppTheoryFunctionProps extends lambda.FunctionProps {
    /**
     * Stable physical name for the AppTheory-managed Lambda execution role.
     *
     * AppTheory preserves the Lambda L2's policies. Concrete names are synthesis-validated against IAM's `[\w+=,.@-]+` character set and 64-character limit.
     * Token-valued names are accepted and IAM validates the resolved value at deploy time, so an invalid resolved name fails deployment rather than synthesis.
     * This exemption keeps account-agnostic synthesis representable for the THE-2861 token-valued-input failure class. Do not combine this with the inherited `role`
     * prop; caller-provided roles own their physical name.
     *
     * @default undefined
     */
    readonly roleName?: string;
    /**
     * Optional AppTheory-managed Lambda alias.
     *
     * When set, the alias points at the function's current version and can also
     * carry provisioned concurrency and CodeDeploy traffic shifting.
     *
     * @default undefined
     */
    readonly alias?: AppTheoryFunctionAliasOptions;
}
export declare class AppTheoryFunction extends Construct {
    readonly fn: lambda.Function;
    readonly logGroup?: logs.ILogGroupRef;
    readonly alias?: lambda.Alias;
    readonly deploymentGroup?: codedeploy.LambdaDeploymentGroup;
    constructor(scope: Construct, id: string, props: AppTheoryFunctionProps);
    private configureAlias;
}

import { CfnResource, Stack, Token } from "aws-cdk-lib";
import { IConstruct, Construct } from "constructs";

import {
  AppTheoryDerivedName,
  AppTheoryDerivedNameInput,
  AppTheoryDerivedNames,
  AppTheoryLoggingProfile,
  AppTheoryNamingProfile,
  AppTheoryNamingContextValues,
  AppTheoryPhysicalName,
  AppTheoryResourceNaming,
  DERIVED_NAMES_METADATA_KEY,
  DERIVED_NAMES_SCHEMA,
  RESOURCE_NAMING_CONTRACT,
} from "./naming";

/**
 * Accepted CloudWatch Logs `RetentionInDays` values. AWS rejects any other
 * value, so the context fails synthesis instead of deferring a deploy-time
 * error.
 */
const ACCEPTED_RETENTION_DAYS = [
  1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653,
];

/**
 * Properties for an `AppTheoryNamingContext`.
 *
 * The context holds the bound naming and logging values from stage config.
 * Constructs take it as an optional prop; with no context every construct
 * synthesizes exactly as it did before this contract existed.
 */
export interface AppTheoryNamingContextProps {
  /**
   * Namespace segment.
   * @default "theorycloud"
   */
  readonly namespace?: string;

  /**
   * App instance id from stage config.
   */
  readonly app: string;

  /**
   * Stage id from stage config.
   */
  readonly stage: string;

  /**
   * Twelve-digit account id from stage config. An unresolved token fails
   * synthesis.
   */
  readonly account: string;

  /**
   * Full Region code, for example `us-east-1`.
   */
  readonly region: string;

  /**
   * Physical pins keyed `{type}:{logical}`, used verbatim under a legacy
   * naming profile.
   * @default {}
   */
  readonly pins?: { [key: string]: string };

  /**
   * Generated-name entries keyed `{type}:{logical}`. An entry means
   * CloudFormation generates the name today, so the construct sets no
   * physical-name property. Valid only under the legacy naming profile.
   * @default []
   */
  readonly generated?: string[];

  /**
   * Naming profile.
   * @default AppTheoryNamingProfile.DERIVED
   */
  readonly namingProfile?: AppTheoryNamingProfile;

  /**
   * Logging profile. `standard` opts every construct that receives the context
   * into the contract's log groups and access logging. `legacy` keeps each
   * construct's pre-contract behaviour.
   * @default AppTheoryLoggingProfile.LEGACY
   */
  readonly loggingProfile?: AppTheoryLoggingProfile;

  /**
   * Retention in days for standard-profile log groups. Must be a value
   * CloudWatch Logs accepts.
   * @default 30
   */
  readonly retentionDays?: number;
}

/**
 * One declared physically named resource: the composed name, and the construct
 * whose CloudFormation resource carries it.
 */
interface AppTheoryNameDeclaration {
  readonly type: string;
  readonly logical: string;
  readonly name?: string;
  readonly generated: boolean;
  readonly resource: IConstruct;
}

/**
 * The bound naming and logging context shared by AppTheory constructs.
 */
export class AppTheoryNamingContext extends Construct {
  /**
   * Namespace segment.
   */
  public readonly namespace: string;

  /**
   * App instance id.
   */
  public readonly app: string;

  /**
   * Stage id.
   */
  public readonly stage: string;

  /**
   * Twelve-digit account id.
   */
  public readonly account: string;

  /**
   * Full Region code.
   */
  public readonly region: string;

  /**
   * Physical pins keyed `{type}:{logical}`.
   */
  public readonly pins: { [key: string]: string };

  /**
   * Generated-name entries keyed `{type}:{logical}`.
   */
  public readonly generated: string[];

  /**
   * The naming entries a construct has consumed at synthesis.
   */
  private readonly consumed = new Set<string>();

  /**
   * The physically named resources a construct has declared (contract section
   * 11.4). Each declaration ties one composed name to the CloudFormation
   * resource that carries it, so synthesis can refuse a collision and emit the
   * derived-name artifact the reservation index reserves.
   */
  private readonly declared: AppTheoryNameDeclaration[] = [];

  /**
   * Naming profile.
   */
  public readonly namingProfile: AppTheoryNamingProfile;

  /**
   * Logging profile.
   */
  public readonly loggingProfile: AppTheoryLoggingProfile;

  /**
   * Retention in days for standard-profile log groups.
   */
  public readonly retentionDays: number;

  constructor(scope: Construct, id: string, props: AppTheoryNamingContextProps) {
    super(scope, id);

    if (Token.isUnresolved(props.account)) {
      throw new Error(
        "AppTheoryNamingContext requires a concrete account id; the naming contract derives physical names from it and an unresolved token cannot be validated at synthesis",
      );
    }
    if (Token.isUnresolved(props.region)) {
      throw new Error("AppTheoryNamingContext requires a concrete region; an unresolved token cannot be validated at synthesis");
    }

    this.namespace = props.namespace ?? "theorycloud";
    this.app = props.app;
    this.stage = props.stage;
    this.account = props.account;
    this.region = props.region;
    this.pins = { ...(props.pins ?? {}) };
    this.generated = [...(props.generated ?? [])];
    this.namingProfile = props.namingProfile ?? AppTheoryNamingProfile.DERIVED;
    this.loggingProfile = props.loggingProfile ?? AppTheoryLoggingProfile.LEGACY;
    this.retentionDays = props.retentionDays ?? 30;

    AppTheoryResourceNaming.validateContext(this.values());

    if (!ACCEPTED_RETENTION_DAYS.includes(this.retentionDays)) {
      throw new Error(
        `AppTheoryNamingContext retentionDays must be one of ${ACCEPTED_RETENTION_DAYS.join(", ")}; CloudWatch Logs rejects other values`,
      );
    }

    this.node.addValidation({
      validate: () => {
        const orphans = [...new Set([...Object.keys(this.pins), ...this.generated])].filter(
          (key) => !this.consumed.has(key),
        );
        const errors: string[] = [];
        if (orphans.length > 0) {
          errors.push(
            `AppTheoryNamingContext naming entries match no resource in the stack: ${orphans.join(", ")}; remove them or pass the matching logical name to the construct that owns the resource`,
          );
        }

        const entries: AppTheoryDerivedNameInput[] = this.declared.map((entry) => ({
          ...(entry.name !== undefined ? { name: entry.name } : {}),
          type: entry.type,
          logicalId: this.cloudFormationLogicalId(entry),
          ...(entry.generated ? { generated: true } : {}),
        }));

        let artifact: AppTheoryDerivedName[] = [];
        try {
          artifact = AppTheoryResourceNaming.synthCheck(entries);
        } catch (error) {
          errors.push(
            `AppTheoryNamingContext ${String((error as Error).message)}; two different logical resources in one naming context cannot share a physical name in the same scope`,
          );
        }
        if (errors.length > 0) return errors;

        const document: AppTheoryDerivedNames = {
          contract: RESOURCE_NAMING_CONTRACT,
          schema: DERIVED_NAMES_SCHEMA,
          context: this.values(),
          entries: artifact,
        };
        this.node.addMetadata(DERIVED_NAMES_METADATA_KEY, JSON.parse(AppTheoryResourceNaming.derivedNamesJson(document)));
        return [];
      },
    });
  }

  /**
   * Whether the standard logging profile is active.
   */
  public get standardLogging(): boolean {
    return this.loggingProfile === AppTheoryLoggingProfile.STANDARD;
  }

  /**
   * The context values as a jsii struct.
   */
  public values(): AppTheoryNamingContextValues {
    return {
      namespace: this.namespace,
      app: this.app,
      stage: this.stage,
      account: this.account,
      region: this.region,
      pins: this.pins,
      generated: this.generated,
      namingProfile: this.namingProfile,
      loggingProfile: this.loggingProfile,
      retentionDays: this.retentionDays,
    };
  }

  /**
   * Compose the physical name of one resource under this context.
   */
  public physicalName(resourceType: string, logical: string): AppTheoryPhysicalName {
    const composed = AppTheoryResourceNaming.physicalName(this.values(), resourceType, logical);
    this.consumed.add(`${resourceType}:${logical}`);
    return composed;
  }

  /**
   * Declare the CloudFormation resource that carries one composed name
   * (contract section 11.4).
   *
   * Synthesis refuses two different logical resources in one naming context that
   * derive the same name in the same naming scope, and emits the derived-name
   * artifact the name reservation index reserves. A construct declares every
   * physically named resource it creates; an application that names its own
   * resource with `physicalName` declares it here once the resource exists, so
   * the artifact covers it too.
   *
   * A name AppTheory only wires for a resource another stack owns, such as
   * `AppTheorySsrSite`'s ISR metadata table, takes no declaration here: that
   * stack declares its own resource.
   *
   * A `log_group` type declares a log-source name (contract section 3): a log
   * group takes no pin or generated entry.
   */
  public declareName(resourceType: string, logical: string, resource: IConstruct): void {
    if (resourceType === "log_group") {
      const name = AppTheoryResourceNaming.logGroupName(this.values(), logical);
      this.declared.push({ type: resourceType, logical, name, generated: false, resource });
      return;
    }
    const composed = this.physicalName(resourceType, logical);
    this.declared.push({
      type: resourceType,
      logical,
      ...(composed.generated ? {} : { name: composed.name }),
      generated: composed.generated === true,
      resource,
    });
  }

  /**
   * The CloudFormation logical id of the resource a declaration names. The
   * construct's default child is the L1 resource a construct creates for itself,
   * so an L2 construct is the expected argument.
   */
  private cloudFormationLogicalId(declaration: AppTheoryNameDeclaration): string {
    const resource: IConstruct = declaration.resource;
    const candidate: IConstruct | undefined =
      resource instanceof CfnResource ? resource : resource.node.defaultChild;
    if (!(candidate instanceof CfnResource)) {
      throw new Error(
        `AppTheoryNamingContext cannot declare ${declaration.type}:${declaration.logical} because ${resource.node.path} has no CloudFormation resource as its default child; declare the construct that owns the named resource`,
      );
    }
    return String(Stack.of(candidate).resolve(candidate.logicalId));
  }

  /**
   * The physical log-group name of a logical source under this context.
   */
  public logGroupName(logical: string): string {
    return AppTheoryResourceNaming.logGroupName(this.values(), logical);
  }

  /**
   * The bound prefix shared by this app's log sources.
   */
  public logSourcePrefix(): string {
    return AppTheoryResourceNaming.logSourcePrefix(this.values());
  }
}

import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import type * as lambda from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
import { AppTheoryRestApiRouter, type AppTheoryRestApiRouterCorsOptions, type AppTheoryRestApiRouterDomainOptions, type AppTheoryRestApiRouterStageOptions } from "./rest-api-router";
/**
 * Props for the AppTheoryRemoteMcpServer construct.
 *
 * This construct is intended for Claude-first Remote MCP deployments:
 * - API Gateway REST API v1 (required for response streaming)
 * - Streamable HTTP mount at `/mcp` (POST/GET/DELETE)
 */
export interface AppTheoryRemoteMcpServerProps {
    /**
     * The Lambda function that handles MCP Streamable HTTP requests.
     */
    readonly handler: lambda.IFunction;
    /**
     * Optional API name.
     * @default undefined
     */
    readonly apiName?: string;
    /**
     * Optional API description.
     * @default undefined
     */
    readonly description?: string;
    /**
     * Stage configuration.
     * @default undefined (router defaults applied)
     */
    readonly stage?: AppTheoryRestApiRouterStageOptions;
    /**
     * CORS configuration for the REST API.
     *
     * Note: For browser clients, your Lambda handler still needs to emit
     * the appropriate `Access-Control-Allow-Origin` headers.
     *
     * @default undefined (no CORS preflight)
     */
    readonly cors?: boolean | AppTheoryRestApiRouterCorsOptions;
    /**
     * Optional custom domain configuration.
     * @default undefined
     */
    readonly domain?: AppTheoryRestApiRouterDomainOptions;
    /**
     * Whether API Gateway console test invocations should be granted Lambda invoke permissions.
     *
     * When false, the construct suppresses the extra `test-invoke-stage` Lambda permissions
     * that CDK adds for each REST API method. This reduces Lambda resource policy size while
     * preserving deployed-stage invoke permissions.
     *
     * @default true
     */
    readonly allowTestInvoke?: boolean;
    /**
     * Whether Lambda invoke permissions should be scoped to individual REST API methods.
     *
     * When false, the construct grants one API-scoped invoke permission per Lambda instead of
     * one permission per method/path pair. This is the scalable choice for large Remote MCP
     * route bundles that share one handler.
     *
     * @default true
     */
    readonly scopePermissionToMethod?: boolean;
    /**
     * Enable per-actor MCP endpoint bundles.
     *
     * When enabled, the construct mounts the transport at `/mcp/{actor}` and
     * co-registers the RFC 9728 discovery route at
     * `/.well-known/oauth-protected-resource/mcp/{actor}`.
     *
     * The public `endpoint` and injected `MCP_ENDPOINT` environment variable
     * become a template string ending in `/mcp/{actor}`.
     *
     * @default false
     */
    readonly actorPath?: boolean;
    /**
     * Register `GET /.well-known/mcp.json` and route it to the handler.
     *
     * This lets the construct own the final MCP discovery route alongside the
     * transport and protected-resource metadata routes. The handler remains
     * responsible for serving the discovery document content.
     *
     * @default false
     */
    readonly enableWellKnownMcpDiscovery?: boolean;
    /**
     * Create a DynamoDB table for MCP session storage.
     * @default false
     */
    readonly enableSessionTable?: boolean;
    /**
     * Session DynamoDB table name (only used when enableSessionTable is true).
     * @default undefined (auto-generated)
     */
    readonly sessionTableName?: string;
    /**
     * Session TTL in minutes (exposed to the handler as MCP_SESSION_TTL_MINUTES).
     * @default 60
     */
    readonly sessionTtlMinutes?: number;
    /**
     * Create a DynamoDB table for stream/event log storage.
     *
     * This is intended for durable resumable SSE implementations where stream
     * events must survive Lambda container recycling.
     *
     * @default false
     */
    readonly enableStreamTable?: boolean;
    /**
     * Stream DynamoDB table name (only used when enableStreamTable is true).
     * @default undefined (auto-generated)
     */
    readonly streamTableName?: string;
    /**
     * Stream/event TTL in minutes (exposed to the handler as MCP_STREAM_TTL_MINUTES).
     * @default 60
     */
    readonly streamTtlMinutes?: number;
}
/**
 * A Claude-first Remote MCP server construct that provisions:
 * - API Gateway REST API v1
 * - Streaming-enabled Lambda proxy integrations for `/mcp` (POST/GET) using
 *   Lambda response streaming (`/response-streaming-invocations`)
 * - Optional DynamoDB tables for sessions and stream/event log state
 *
 * This construct is designed for MCP Streamable HTTP (2025-06-18).
 */
export declare class AppTheoryRemoteMcpServer extends Construct {
    /**
     * The underlying REST API router.
     */
    readonly router: AppTheoryRestApiRouter;
    /**
     * The MCP endpoint URL or template (`.../mcp` or `.../mcp/{actor}`).
     */
    readonly endpoint: string;
    /**
     * The DynamoDB session table (if enabled).
     */
    readonly sessionTable?: dynamodb.ITable;
    /**
     * The DynamoDB stream/event log table (if enabled).
     */
    readonly streamTable?: dynamodb.ITable;
    constructor(scope: Construct, id: string, props: AppTheoryRemoteMcpServerProps);
    /**
     * Add an environment variable to the Lambda function.
     * Uses addEnvironment if available (Function), otherwise no-op for imported functions.
     */
    private addEnvironment;
}

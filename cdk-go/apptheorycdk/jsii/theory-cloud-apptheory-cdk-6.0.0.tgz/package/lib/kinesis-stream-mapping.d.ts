import type { Duration } from "aws-cdk-lib";
import type * as kinesis from "aws-cdk-lib/aws-kinesis";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
/**
 * Properties for AppTheoryKinesisStreamMapping.
 */
export interface AppTheoryKinesisStreamMappingProps {
    /**
     * The Lambda function that will consume records from the stream.
     */
    readonly consumer: lambda.IFunction;
    /**
     * The Kinesis Data Stream to consume.
     */
    readonly stream: kinesis.IStream;
    /**
     * Where to begin consuming the stream.
     *
     * @default lambda.StartingPosition.LATEST
     */
    readonly startingPosition?: lambda.StartingPosition;
    /**
     * The Unix timestamp, in seconds, used with lambda.StartingPosition.AT_TIMESTAMP.
     *
     * @default - no timestamp
     */
    readonly startingPositionTimestamp?: number;
    /**
     * The largest number of records that AWS Lambda retrieves per invocation.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly batchSize?: number;
    /**
     * The maximum amount of time to gather records before invoking the function.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly maxBatchingWindow?: Duration;
    /**
     * Maximum number of retry attempts for failed records.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly retryAttempts?: number;
    /**
     * The maximum age of a record that Lambda sends to the consumer.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly maxRecordAge?: Duration;
    /**
     * Split a failed batch in two and retry.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly bisectBatchOnError?: boolean;
    /**
     * The number of batches to process from each shard concurrently.
     *
     * @default - AWS Lambda default for Kinesis event source mappings
     */
    readonly parallelizationFactor?: number;
    /**
     * Allow partial-batch failure responses from the consumer.
     *
     * AppTheory defaults this on so Kinesis consumers can fail closed per record
     * instead of replaying successfully processed records.
     *
     * @default true
     */
    readonly reportBatchItemFailures?: boolean;
    /**
     * The tumbling window used to group records before invocation.
     *
     * @default - no tumbling window
     */
    readonly tumblingWindow?: Duration;
    /**
     * Destination for the records Lambda discards after retries are exhausted or `maxRecordAge` elapses.
     *
     * Pass an event source DLQ, such as `new lambdaEventSources.SqsDlq(queue)` or
     * `new lambdaEventSources.SnsDlq(topic)`. Binding that DLQ grants the consumer role exactly the
     * permission the destination needs (`sqs:SendMessage` or `sns:Publish`); an Amazon S3 bucket
     * (`new lambdaEventSources.S3OnFailureDestination(bucket)`) is also supported.
     *
     * What the destination receives depends on its type. An Amazon SQS or Amazon SNS destination
     * receives metadata about the discarded batch - the shard ID and the start and end sequence
     * numbers - which identify records to re-read from the stream while they are still inside the
     * stream retention window; it does not receive the record payloads. An Amazon S3 destination
     * (`S3OnFailureDestination`) receives the full records, including their payloads. The destination
     * only receives anything once retries are exhausted or `maxRecordAge` is exceeded, so a mapping
     * that leaves both unbounded (the AWS Lambda default is `-1`, retry until the record expires) has
     * nothing to send. Pair this prop with a bounded `retryAttempts` and `bisectBatchOnError: true` so
     * a poison record is retained for repair instead of blocking its shard.
     *
     * @default - discarded records are dropped
     */
    readonly onFailure?: lambda.IEventSourceDlq;
}
/**
 * Wires a Kinesis Data Stream to a Lambda consumer.
 *
 * The mapping owns no stream lifecycle. Use AppTheoryKinesisStream when the
 * application should create or wrap the stream, then pass its `stream` here.
 */
export declare class AppTheoryKinesisStreamMapping extends Construct {
    constructor(scope: Construct, id: string, props: AppTheoryKinesisStreamMappingProps);
}

import { RemovalPolicy } from "aws-cdk-lib";
import * as acm from "aws-cdk-lib/aws-certificatemanager";
import * as cloudfront from "aws-cdk-lib/aws-cloudfront";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as route53 from "aws-cdk-lib/aws-route53";
import * as s3 from "aws-cdk-lib/aws-s3";
import { Construct } from "constructs";
import { AppTheoryCloudFrontLogFormat } from "./logging";
import type { AppTheoryNamingContext } from "./naming-context";
export declare enum AppTheorySsrSiteMode {
    /**
     * Lambda Function URL is the default origin. Direct S3 behaviors are used only for
     * immutable assets and any explicitly configured static path patterns.
     */
    SSR_ONLY = "ssr-only",
    /**
     * S3 is the primary HTML origin and Lambda SSR/ISR is the fallback. FaceTheory hydration
     * data routes are kept on S3 and the edge rewrites extensionless paths to `/index.html`.
     */
    SSG_ISR = "ssg-isr"
}
export interface AppTheorySsrSiteProps {
    readonly ssrFunction: lambda.IFunction;
    /**
     * Explicit deployment mode for the site topology.
     *
     * - `ssr-only`: Lambda Function URL is the default origin
     * - `ssg-isr`: S3 is the primary HTML origin and Lambda is the fallback
     *
     * Existing implicit behavior maps to `ssr-only`.
     * @default AppTheorySsrSiteMode.SSR_ONLY
     */
    readonly mode?: AppTheorySsrSiteMode;
    /**
     * Lambda Function URL invoke mode for the SSR origin.
     * @default lambda.InvokeMode.RESPONSE_STREAM
     */
    readonly invokeMode?: lambda.InvokeMode;
    /**
     * Function URL auth type for the SSR origin.
     *
     * If omitted, AppTheory fails closed to `AWS_IAM` and signs CloudFront-to-Lambda
     * traffic with lambda Origin Access Control.
     *
     * Set this explicitly to `NONE` only when you intentionally require public
     * direct Function URL access as a deliberate compatibility choice.
     * @default lambda.FunctionUrlAuthType.AWS_IAM
     */
    readonly ssrUrlAuthType?: lambda.FunctionUrlAuthType;
    readonly assetsBucket?: s3.IBucket;
    readonly assetsPath?: string;
    readonly assetsKeyPrefix?: string;
    readonly assetsManifestKey?: string;
    /**
     * Optional S3 bucket used by FaceTheory ISR HTML storage (`S3HtmlStore`).
     *
     * When provided, AppTheory grants the SSR function read/write access and wires:
     * - `FACETHEORY_ISR_BUCKET`
     * - `FACETHEORY_ISR_PREFIX`
     */
    readonly htmlStoreBucket?: s3.IBucket;
    /**
     * S3 key prefix used by FaceTheory ISR HTML storage.
     * @default isr
     */
    readonly htmlStoreKeyPrefix?: string;
    /**
     * Additional extensionless HTML section path patterns to route directly to the primary HTML S3 origin.
     *
     * Requests like `/marketing` and `/marketing/...` are rewritten to `/index.html`
     * within the section and stay on S3 instead of falling back to Lambda.
     *
     * Example direct-S3 HTML section path: "/marketing/*"
     */
    readonly staticPathPatterns?: string[];
    /**
     * Additional raw S3 object/data path patterns that should bypass extensionless HTML rewrites.
     *
     * In `ssg-isr` mode, `/_facetheory/data/*` is added automatically.
     * Example direct-S3 object path: "/feeds/*"
     */
    readonly directS3PathPatterns?: string[];
    /**
     * Additional path patterns that should bypass the `ssg-isr` origin group and route directly
     * to the Lambda Function URL with full method support.
     *
     * In `ssg-isr` mode, `/_facetheory/ssr-data/*` is added automatically for FaceTheory
     * strict no-inline-CSP SSR hydration sidecars.
     *
     * Use this for same-origin dynamic paths such as auth callbacks, actions, or form posts.
     * Example direct-SSR path: "/actions/*"
     */
    readonly ssrPathPatterns?: string[];
    /**
     * Additional bearer-auth Lambda Function URL co-origins to attach to the same CloudFront distribution.
     *
     * AppTheory creates each co-origin Function URL with `AuthType.NONE` and routes the supplied
     * path patterns to it without Lambda Origin Access Control. The SSR origin remains governed by
     * `ssrUrlAuthType` and still defaults to `AWS_IAM` plus Lambda OAC.
     *
     * Co-origin paths participate in AppTheory's behavior path collision checks and bypass `ssg-isr`
     * HTML rewrites. This is the supported AppTheory path for mixed-auth distributions; do not hand-wire
     * raw `distribution.addBehavior(...)` calls when AppTheory should own path and edge-context policy.
     *
     * Example bearer API paths: `["/api/*", "/auth/*"]`.
     */
    readonly bearerFunctionUrlOrigins?: AppTheorySsrSiteBearerFunctionUrlOrigin[];
    /**
     * Optional TableTheory/DynamoDB table used for FaceTheory ISR metadata and lease coordination.
     *
     * When provided, AppTheory grants the SSR function read/write access and wires the
     * metadata table aliases expected by the documented FaceTheory deployment shape.
     */
    readonly isrMetadataTable?: dynamodb.ITable;
    /**
     * Optional ISR/cache metadata table name to wire when you are not passing `isrMetadataTable`.
     *
     * Prefer `isrMetadataTable` when AppTheory should also grant access to the SSR Lambda.
     */
    readonly isrMetadataTableName?: string;
    /**
     * Legacy alias for `isrMetadataTableName`.
     * @deprecated prefer `isrMetadataTable` or `isrMetadataTableName`
     */
    readonly cacheTableName?: string;
    readonly wireRuntimeEnv?: boolean;
    /**
     * Additional headers to forward to the SSR origin (Lambda Function URL) via the origin request policy.
     *
     * The default AppTheory/FaceTheory-safe edge contract forwards only:
     * - `cloudfront-forwarded-proto`
     * - `cloudfront-viewer-address`
     * - `x-apptheory-original-host`
     * - `x-apptheory-original-uri`
     * - `x-facetheory-original-host`
     * - `x-facetheory-original-uri`
     * - `x-request-id`
     *
     * Use this to opt in to additional app-specific headers such as
     * `x-facetheory-segment`. Tenant-like viewer headers are rejected unless
     * `allowViewerTenantHeaders` is explicitly enabled as a compatibility mode.
     * `host` and `x-forwarded-proto` are rejected because they break or bypass the
     * supported origin model.
     */
    readonly ssrForwardHeaders?: string[];
    /**
     * Compatibility escape hatch for legacy viewer-supplied tenant headers.
     *
     * When false (default), AppTheory strips `x-tenant-id` at the edge and rejects
     * tenant-like entries in `ssrForwardHeaders` so viewer-supplied tenant headers
     * cannot influence origin routing or HTML cache partitioning. When true,
     * AppTheory restores legacy passthrough behavior for `x-tenant-id` and any
     * tenant-like `ssrForwardHeaders`.
     *
     * Prefer deriving tenant from trusted host mapping using the original-host
     * edge headers instead of enabling passthrough.
     * @default false
     */
    readonly allowViewerTenantHeaders?: boolean;
    /**
     * Optional naming and logging context.
     *
     * With the standard logging profile the buckets this construct creates take
     * their names from the contract and CloudFront access logs go to
     * `logs/access/cdn/{logicalName}` through CloudWatch Logs vended delivery.
     * Pass `enableLogging: false` to opt out of the delivery.
     *
     * With no context the construct synthesizes exactly as before.
     *
     * @default undefined
     */
    readonly namingContext?: AppTheoryNamingContext;
    /**
     * The site's logical name. Defaults to the kebab-cased construct id when a
     * naming context is present.
     *
     * @default undefined
     */
    readonly logicalName?: string;
    /**
     * CloudFront standard-logging output format for a CloudWatch Logs
     * destination. Only used under the standard logging profile.
     * @default AppTheoryCloudFrontLogFormat.JSON
     */
    readonly cloudFrontLogFormat?: AppTheoryCloudFrontLogFormat;
    readonly enableLogging?: boolean;
    readonly logsBucket?: s3.IBucket;
    /**
     * CloudFront response headers policy applied to SSR and direct-S3 behaviors.
     *
     * If omitted, AppTheory provisions a FaceTheory-aligned baseline policy at the CDN
     * layer: HSTS, nosniff, frame-options, referrer-policy, XSS protection, and a
     * restrictive permissions-policy. Content-Security-Policy remains origin-defined.
     */
    readonly responseHeadersPolicy?: cloudfront.IResponseHeadersPolicy;
    /**
     * Cache policy applied to direct Lambda-backed SSR behaviors.
     *
     * The default is `CACHING_DISABLED` so dynamic Lambda routes stay safe unless you
     * intentionally opt into a cache policy that matches your app's variance model.
     * @default cloudfront.CachePolicy.CACHING_DISABLED
     */
    readonly ssrCachePolicy?: cloudfront.ICachePolicy;
    /**
     * Cache policy applied to the cacheable HTML behavior in `ssg-isr` mode.
     *
     * The default AppTheory policy keys on query strings plus the stable public HTML
     * variant headers (`x-*-original-host` and any non-tenant extra forwarded
     * headers you opt into) while leaving cookies out of the cache key. Tenant-like
     * viewer headers join the cache key only when `allowViewerTenantHeaders` is
     * explicitly enabled.
     */
    readonly htmlCachePolicy?: cloudfront.ICachePolicy;
    readonly removalPolicy?: RemovalPolicy;
    readonly autoDeleteObjects?: boolean;
    readonly domainName?: string;
    /**
     * Route53 hosted zone for DNS records and optional certificate validation.
     *
     * When `domainName` is set without `certificateArn`, hosted-zone certificate
     * creation is allowed only for stacks whose region is explicitly `us-east-1`.
     * CloudFront requires viewer certificates in `us-east-1`; environment-agnostic
     * or other-region stacks must provide `certificateArn`.
     */
    readonly hostedZone?: route53.IHostedZone;
    /**
     * Existing ACM certificate ARN for the CloudFront distribution.
     *
     * The certificate must be in `us-east-1` for CloudFront.
     */
    readonly certificateArn?: string;
    /**
     * Minimum TLS protocol version for viewers of a custom domain.
     *
     * With a derived naming context and a custom certificate the default is
     * `TLS_V1_2_2025`, the policy Security Hub CloudFront.15 accepts with the
     * widest client support. Without a certificate CloudFront serves the fixed
     * default certificate and this property has no effect.
     *
     * @default TLS_V1_2_2025 under a derived naming context with a certificate,
     * otherwise the CloudFront default for the certificate
     */
    readonly minimumProtocolVersion?: cloudfront.SecurityPolicyProtocol;
    /**
     * Object CloudFront returns for a request to the distribution root.
     *
     * With a derived naming context and `mode: ssg-isr` the default is
     * `index.html`, because that mode's default behavior is the S3 HTML store
     * (Security Hub CloudFront.1). `ssr-only` also carries an S3 origin (the
     * asset bucket), so the control evaluates the distribution, but `/` must
     * reach the function URL; a default root object would rewrite `/` onto the
     * function URL, so AppTheory deliberately sets none and the control reports
     * a residual finding.
     *
     * @default "index.html" under a derived naming context in `ssg-isr` mode
     */
    readonly defaultRootObject?: string;
    readonly webAclId?: string;
    /**
     * Bucket that receives S3 server access logs for the buckets this construct
     * creates, which is what Security Hub S3.9 evaluates.
     *
     * Off by default because the log target and its storage cost money. The target
     * bucket is yours: it takes no naming entry (resource-naming contract
     * section 4), and it should not itself be logged.
     *
     * @default no server access logging
     */
    readonly serverAccessLogsBucket?: s3.IBucket;
    /**
     * Key prefix for the server access logs. Only used with
     * `serverAccessLogsBucket`.
     *
     * @default no prefix
     */
    readonly serverAccessLogsPrefix?: string;
}
export interface AppTheorySsrSiteBearerFunctionUrlOrigin {
    /**
     * Lambda function that AppTheory exposes as a bearer-auth Function URL co-origin.
     *
     * AppTheory creates the Function URL with `lambda.FunctionUrlAuthType.NONE`; authentication remains
     * the responsibility of the Lambda handler.
     */
    readonly function: lambda.IFunction;
    /**
     * CloudFront path patterns that route to this co-origin.
     *
     * Patterns are normalized the same way as `ssrPathPatterns`. A pattern ending in `/*` also creates
     * a root behavior without the wildcard so `/api/*` covers both `/api` and `/api/...`.
     */
    readonly pathPatterns: string[];
    /**
     * Lambda Function URL invoke mode for this co-origin.
     * @default lambda.InvokeMode.BUFFERED
     */
    readonly invokeMode?: lambda.InvokeMode;
}
export declare class AppTheorySsrSite extends Construct {
    readonly assetsBucket: s3.IBucket;
    readonly assetsKeyPrefix: string;
    readonly assetsManifestKey: string;
    readonly htmlStoreBucket?: s3.IBucket;
    readonly htmlStoreKeyPrefix?: string;
    readonly isrMetadataTable?: dynamodb.ITable;
    readonly logsBucket?: s3.IBucket;
    readonly ssrUrl: lambda.FunctionUrl;
    readonly bearerFunctionUrls: lambda.FunctionUrl[];
    readonly distribution: cloudfront.Distribution;
    readonly certificate?: acm.ICertificate;
    readonly responseHeadersPolicy: cloudfront.IResponseHeadersPolicy;
    constructor(scope: Construct, id: string, props: AppTheorySsrSiteProps);
}

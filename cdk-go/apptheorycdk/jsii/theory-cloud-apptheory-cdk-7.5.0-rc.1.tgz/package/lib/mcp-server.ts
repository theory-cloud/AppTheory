import { RemovalPolicy, Stack, Token } from "aws-cdk-lib";
import { createHash } from "node:crypto";
import * as acm from "aws-cdk-lib/aws-certificatemanager";
import * as apigwv2 from "aws-cdk-lib/aws-apigatewayv2";
import * as apigwv2Authorizers from "aws-cdk-lib/aws-apigatewayv2-authorizers";
import * as apigwv2Integrations from "aws-cdk-lib/aws-apigatewayv2-integrations";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as iam from "aws-cdk-lib/aws-iam";
import type * as kms from "aws-cdk-lib/aws-kms";
import type * as lambda from "aws-cdk-lib/aws-lambda";
import * as logs from "aws-cdk-lib/aws-logs";
import * as route53 from "aws-cdk-lib/aws-route53";
import { Construct } from "constructs";

import { AppTheoryMcpRouteAlgebra } from "./mcp-route-algebra";
import { defaultLogicalName } from "./private/logical-name";
import { refuseExplicitName } from "./private/refuse-explicit-name";
import {
  RECOMMENDED_HTTP_API_SECURITY_POLICY,
  defaultDeletionProtection,
  secureDefaults,
} from "./private/secure-defaults";
import { httpApiAccessLogFormat, retentionFor } from "./private/standard-logging";
import type { AppTheoryNamingContext } from "./naming-context";
import { buildCorsPreflight } from "./cors";
import type { AppTheoryHttpApiCorsOptions } from "./http-api";
import { semanticRouteConstructId } from "./route-ids";

const CONSOLIDATED_ROOT_ROUTE_ID = "RouteAnyRoot";
const CONSOLIDATED_PROXY_ROUTE_ID = "RouteAnyProxy";
const DEFAULT_THROTTLING_RATE_LIMIT = 100;
const DEFAULT_THROTTLING_BURST_LIMIT = 200;
const DEFAULT_SESSION_TTL_MINUTES = 60;
const MCP_TRANSPORT_AUTHORIZER_ID = "McpTransportAuthorizer";
const MCP_TRANSPORT_POSTURE_METADATA_KEY = "apptheory:mcp-transport-posture";
const MCP_TRANSPORT_POSTURE_CONTRACT_ID = "m17.mcp-transport-posture/v1";
const MCP_DENIAL_METRIC_NAME = "apptheory.mcp.auth_denied";
const MCP_DENIAL_DIMENSIONS = ["outcome", "route_family"];

/** The front-door header name alphabet. */
const FRONT_DOOR_HEADER_NAME_PATTERN = /^[A-Za-z0-9-]{1,64}$/;

/** The front-door secret alphabet: header-value-safe, no whitespace or controls. */
const FRONT_DOOR_SECRET_PATTERN = /^[A-Za-z0-9._~-]{32,128}$/;

/**
 * A well-known SSM parameter name, in the alphabet a CloudFormation `ssm`
 * dynamic reference accepts.
 *
 * https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/dynamic-references-ssm.html
 */
const FRONT_DOOR_PARAMETER_NAME_PATTERN = /^\/[A-Za-z0-9_.\-/]+$/;

/**
 * The SSM parameter-name limits: 1011 characters including the ARN prefix, a
 * fifteen-level hierarchy, and no `aws`/`ssm` prefix.
 *
 * https://docs.aws.amazon.com/systems-manager/latest/APIReference/API_PutParameter.html
 */
const FRONT_DOOR_PARAMETER_NAME_MAX_LENGTH = 1011;
const FRONT_DOOR_PARAMETER_NAME_MAX_LEVELS = 15;

/**
 * Request headers a front door can never carry the verification in: they either
 * rewrite the origin request contract or are platform-managed, so a declared
 * value could not be verified the way the runtime reads it.
 */
const RESERVED_FRONT_DOOR_HEADERS = new Set([
  "authorization",
  "connection",
  "content-length",
  "cookie",
  "host",
  "transfer-encoding",
  "www-authenticate",
  "x-forwarded-for",
]);


/** Route-emission model for AppTheoryMcpServer. */
export enum AppTheoryMcpRouteModel {
  /**
   * One API Gateway HTTP API v2 route per derived route key. This is the
   * construct's historical inventory and stays byte-identical for deployed
   * stacks, so a `routeModel: explicit` upgrade deploys in place. The default.
   */
  EXPLICIT = "explicit",
  /**
   * Two greedy routes, `ANY /` and `ANY /{proxy+}`, backed by one shared
   * integration. The AppTheory runtime router performs method and path
   * dispatch, path-parameter capture, and denial. Consolidation never changes
   * gateway admission, so it is valid only when every gateway route is `NONE`:
   * the `runtime-bearer` and `none-public` transport postures. `iam` and `jwt`
   * are refused at synthesis time.
   */
  CONSOLIDATED = "consolidated",
}

/** Construct-id derivation for the explicit route model. */
export enum AppTheoryMcpRouteIdMode {
  /**
   * Positional ids (`Route0`, `Route1`, ...) assigned in emission order. This
   * is the construct's historical inventory and stays byte-identical for
   * deployed stacks. The default.
   */
  LEGACY = "legacy",
  /**
   * Ids derived from the route method and pattern, so inserting, removing, or
   * reordering a route family never renames an unrelated route. Intended for
   * newly created explicit APIs: switching an existing deployed explicit API
   * from `legacy` to `semantic` in place renames every route, which is itself a
   * create-before-delete collision. Adopt it on an existing stack only through
   * the new-API swap described in `UPGRADING.md`.
   */
  SEMANTIC = "semantic",
}

/** Transport-route authorization posture for AppTheoryMcpServer. */
export enum AppTheoryMcpTransportPosture {
  /** AWS IAM (SigV4) on the transport routes. The default for a server with no facade attachment. */
  IAM = "iam",
  /** A static JWT authorizer (issuer + audience) on the transport routes. */
  JWT = "jwt",
  /** The gateway authorizer is NONE and the runtime validates RFC 9728 bearer tokens. The default for a facade-configured server. */
  RUNTIME_BEARER = "runtime-bearer",
  /** Deliberately public MCP server: every transport route is public. Never a default. */
  NONE_PUBLIC = "none-public",
}

/** Presence-only skeleton of the upstream-provider attachment that selects the facade-scoped default. */
export interface AppTheoryMcpFacadeAttachment {
  /** Identifies the upstream authorization provider this server fronts (for example `autheory`). Provider wiring lands in M3; this milestone validates the attachment shape and uses its presence to select the `runtime-bearer` default. */
  readonly providerId: string;
}

/** Runtime-side declaration that the transport routes validate RFC 9728 bearer tokens at runtime. */
export interface AppTheoryMcpRuntimePostureOptions {
  /** Assert the runtime registers the transport routes with the runtime-validated bearer posture (Go `FacadeConfig.RequireBearerToken`, TS `requireBearerTokenMiddleware`, Python `require_bearer_token_middleware`). Must be `true`. */
  readonly requireBearerToken: boolean;
}

/** Direct-origin reachability decision required under `runtime-bearer` and `none-public`. */
export enum AppTheoryMcpOriginReachability {
  /**
   * Disable the execute-api default endpoint and advertise an owned ordinary
   * custom domain as the only MCP authority.
   */
  DISABLED = "disabled",
  /**
   * Disable the execute-api default endpoint and require mutual TLS on every
   * custom domain mapped to the construct-owned API. The owned domain's
   * `mutualTlsAuthentication` is the concrete lock; an enum alone or an
   * external/attached front door never satisfies it.
   */
  LOCKED = "locked",
  /**
   * The origin stays directly reachable at its execute-api endpoint and is
   * served only through an application-owned front door that injects
   * `frontDoorVerification` on every origin request.
   *
   * This is the posture for an app-owned distribution whose origin is the
   * execute-api hostname: the construct sees neither the distribution nor the
   * API's endpoint configuration, so it cannot produce in-stack evidence the
   * way `DISABLED` and `LOCKED` do. Valid only in attach mode, accepted with
   * `RUNTIME_BEARER` and `NONE_PUBLIC` like the other decisions, and it
   * requires the mandatory `frontDoorVerification` declaration.
   *
   * `FRONTED` is a defense-in-depth declaration with runtime enforcement, not
   * mutual-TLS assurance and not origin unreachability. The enforcement is the
   * runtime's front-door header check (`mcpfacade.FacadeConfig`
   * `FrontDoorVerification` in Go, `frontDoorVerification` in TypeScript,
   * `front_door_verification` in Python): it refuses every derived route when
   * the declared header is absent or wrong, and fails registration when
   * `FRONTED` is declared without it. An unwired runtime enforces nothing.
   */
  FRONTED = "fronted",
}

/**
 * Front-door verification for `originReachability: FRONTED`.
 *
 * Attach mode means the front door is application-owned, so the construct
 * cannot inject the header itself and cannot observe the distribution. The
 * declaration therefore carries three independently wired copies that must come
 * from one application-owned constant: this prop, the distribution's origin
 * custom-header configuration, and the runtime's front-door verification
 * config. The construct proves only its own copy.
 *
 * Supply exactly one of `secretValue` and `secretParameterName`:
 *
 * - `secretValue` is the v7.3 literal form. It is consumed at synthesis for
 *   validation and the recorded SHA-256 digest only, and it never lands in the
 *   construct's own synthesized template.
 * - `secretParameterName` names a well-known, stage-qualified Parameter Store
 *   parameter that the application's installer creates if absent. The value
 *   never enters the application source: the construct renders the header value
 *   as a CloudFormation `ssm` dynamic reference and records the parameter name
 *   instead of a digest.
 */
export interface AppTheoryMcpFrontDoorVerificationOptions {
  /**
   * The origin request header the front door injects on every request it sends
   * to the origin.
   *
   * 1 to 64 characters of `[A-Za-z0-9-]`, and never a request header that
   * rewrites the origin contract (`Host`, `Authorization`, `Cookie`,
   * `Content-Length`, `Transfer-Encoding`, `Connection`, `WWW-Authenticate`,
   * `X-Forwarded-For`), any `x-amz-*`/`x-amzn-*`/`cloudfront-*` name, or a
   * hop-by-hop name.
   */
  readonly headerName: string;

  /**
   * The literal secret injected as the front-door header value.
   *
   * 32 to 128 characters of `[A-Za-z0-9._~-]`: a header-value-safe alphabet
   * with no whitespace and no control characters. The value is consumed at
   * synthesis for validation and the recorded SHA-256 digest only — the literal
   * never lands in the construct's synthesized template or in CloudFormation.
   * It is not a credential store; rotation means changing the value and
   * redeploying, and it must not be (or contain) a secret that protects
   * anything else.
   *
   * Mutually exclusive with `secretParameterName`. Prefer the parameter form:
   * a committed literal is exactly what the parameter form removes.
   * @default undefined
   */
  readonly secretValue?: string;

  /**
   * The well-known, stage-qualified Parameter Store parameter that holds the
   * front-door secret.
   *
   * A fully qualified name from `/`, at most 1011 characters and fifteen
   * levels, in the `[A-Za-z0-9_.\-/]` alphabet a CloudFormation `ssm` dynamic
   * reference accepts, and never in the reserved `aws`/`ssm` hierarchy.
   *
   * The parameter must be type **String**, not SecureString: CloudFront's
   * `OriginCustomHeaders` supports the plaintext `ssm` reference only, and AWS
   * lists the properties that support `ssm-secure` exhaustively (CloudFront is
   * not one of them). The value is therefore defense-in-depth against direct
   * origin access, not a confidentiality control — the same posture as the
   * literal form, which CloudFront already exposes through
   * `GetDistributionConfig`.
   *
   * `frontDoorOriginHeader` renders the dynamic reference for the distribution
   * the app wires, e.g. `{{resolve:ssm:/theorycloud/tms/lab/fronted-token}}`,
   * and the construct grants `ssm:GetParameter` on exactly this parameter to
   * `handler`. A stack update re-resolves the latest parameter version; drift
   * detection does not see dynamic references.
   *
   * Mutually exclusive with `secretValue`.
   * @default undefined
   */
  readonly secretParameterName?: string;

  /**
   * The customer managed key that encrypts the parameter when it is a
   * SecureString.
   *
   * FRONTED cannot use a SecureString for the distribution header (see
   * `secretParameterName`), so this is only meaningful when the same well-known
   * name is also read for a purpose other than the origin header. When it is
   * set the construct grants `kms:Decrypt` on the key to `handler`. Leave it
   * unset for a String parameter: Parameter Store needs no KMS permission for
   * plaintext values.
   * @default undefined
   */
  readonly secretParameterKmsKey?: kms.IKey;

  /**
   * The assertion that the runtime verifies the front-door header on every
   * derived route.
   *
   * The construct cannot attach that verification to an application-owned front
   * door or a runtime it does not own, so it refuses to synthesize until the
   * caller records that the verification exists. Must be `true`.
   */
  readonly asserted: boolean;
}

/**
 * The origin custom header the application wires into its front door.
 *
 * `headerValue` is the literal for the literal form and a CloudFormation
 * `ssm` dynamic reference for the parameter form, so the parameter value never
 * enters the application source.
 */
export interface AppTheoryMcpFrontDoorHeader {
  /** The origin request header name to send to the origin. */
  readonly headerName: string;
  /** The header value: a literal, or a `{{resolve:ssm:...}}` dynamic reference. */
  readonly headerValue: string;
}

/** Denial-telemetry declaration required under `runtime-bearer`. */
export interface AppTheoryMcpDenialSignalOptions {
  /** Denial metric name. Must be `apptheory.mcp.auth_denied`. @default apptheory.mcp.auth_denied */
  readonly metricName?: string;
  /** Bounded metric dimensions. Must be exactly `outcome` and `route_family`. @default ["outcome", "route_family"] */
  readonly dimensions?: string[];
}

/** Owning-API stage throttling decision. */
export interface AppTheoryMcpOwningApiThrottlingOptions {
  /** Stage rate limit in requests per second. */
  readonly rateLimit: number;
  /** Stage burst limit. */
  readonly burstLimit: number;
}

/** Attach-mode record of the owning API's defense-in-depth decisions (required under `runtime-bearer` and `none-public`). */
export interface AppTheoryMcpOwningApiDefenseOptions {
  /** Whether the owning API's stage has access logging enabled. Must be true. */
  readonly accessLogging: boolean;
  /** The owning API's stage throttling decision. */
  readonly throttling: AppTheoryMcpOwningApiThrottlingOptions;
}

/** Static JWT configuration for `transportPosture: JWT`. */
export interface AppTheoryMcpTransportAuthorizerOptions {
  /** Absolute HTTPS JWT issuer URL. Required under `transportPosture: JWT`. @default undefined */
  readonly issuer?: string;
  /** Accepted JWT audiences. Required under `transportPosture: JWT`. @default undefined */
  readonly audience?: string[];
  /** Identity sources for the JWT authorizer. @default ["$request.header.Authorization"] */
  readonly identitySource?: string[];
  /** JWT authorizer resource name. @default the authorizer construct id */
  readonly authorizerName?: string;
}

/** Custom domain configuration for an AppTheory-owned MCP HTTP API. */
export interface AppTheoryMcpServerDomainOptions {
  /** The custom domain name (for example, `mcp.example.com`). */
  readonly domainName: string;

  /** ACM certificate for the domain. Provide this or `certificateArn`. */
  readonly certificate?: acm.ICertificate;

  /** ACM certificate ARN. Provide this or `certificate`. */
  readonly certificateArn?: string;

  /**
   * Route53 hosted zone for an automatically created CNAME record.
   * @default undefined
   */
  readonly hostedZone?: route53.IHostedZone;

  /**
   * Mutual TLS truststore for the owned custom domain.
   *
   * Supplying this is the concrete `AppTheoryMcpOriginReachability.LOCKED`
   * evidence: the construct disables the default execute-api endpoint and
   * requires every API mapping bound to the owned API to target a domain whose
   * `MutualTlsAuthentication` carries a truststore URI. Supplying it with any
   * other origin decision, or selecting `LOCKED` without it, fails synthesis.
   * @default undefined
   */
  readonly mutualTlsAuthentication?: apigwv2.MTLSConfig;

  /**
   * TLS security policy for the owned custom domain.
   *
   * Under a derived naming context the default is TLS 1.2, the strongest policy
   * API Gateway v2 offers. Security Hub APIGateway.11 always fails a custom
   * domain attached to an HTTP API, so no policy satisfies it there.
   *
   * @default TLS 1.2 under a derived naming context, otherwise the API Gateway default
   */
  readonly securityPolicy?: apigwv2.SecurityPolicy;
}

/** Stage configuration for an AppTheory-owned MCP HTTP API. */
export interface AppTheoryMcpServerStageOptions {
  /** @default "$default" */
  readonly stageName?: string;

  /** @default true */
  readonly accessLogging?: boolean;

  /**
   * Retention period for the access log group. Valid only when access logging
   * is enabled.
   * @default logs.RetentionDays.ONE_MONTH
   */
  readonly accessLogRetention?: logs.RetentionDays;

  /** @default true */
  readonly throttlingEnabled?: boolean;

  /**
   * Default-stage rate limit in requests per second.
   * @default 100
   */
  readonly throttlingRateLimit?: number;

  /**
   * Default-stage burst limit.
   * @default 200
   */
  readonly throttlingBurstLimit?: number;
}

/** Owned-API specialization for standalone MCP servers. */
export interface AppTheoryMcpServerOwnedApiOptions {
  /** Optional API name. */
  readonly apiName?: string;

  /** Optional custom domain owned by this construct. */
  readonly domain?: AppTheoryMcpServerDomainOptions;

  /**
   * Stage configuration. Access logging and throttling default on.
   * @default production defaults
   */
  readonly stage?: AppTheoryMcpServerStageOptions;
}

/** Ordered MCP route-pattern family wired as one facade. */
export interface AppTheoryMcpRouteFamily {
  /**
   * Ordered synthesis-time MCP route patterns.
   *
   * Each segment is either a literal RFC 3986 path segment or a complete
   * `{parameter_name}` segment. CDK tokens, origins, empty segments, dot
   * segments, greedy parameters, and duplicate patterns are rejected.
   */
  readonly patterns: string[];

  /**
   * Wire the algebra-derived unscoped authorization-server discovery route.
   * The runtime must supply `FacadeConfig.RootAuthorizationServer` too.
   * @default false
   */
  readonly rootAuthorizationServerDiscovery?: boolean;
}

/** DynamoDB-backed MCP session-state configuration. */
export interface AppTheoryMcpSessionStateOptions {
  /** @default true */
  readonly enabled?: boolean;

  /**
   * Session table name. Valid only when session state is enabled.
   * @default auto-generated
   */
  readonly tableName?: string;

  /**
   * TTL in minutes for session records. Valid only when session state is
   * enabled.
   * @default 60
   */
  readonly ttlMinutes?: number;

  /**
   * Session table removal policy. Valid only when session state is enabled.
   * @default RemovalPolicy.RETAIN
   */
  readonly removalPolicy?: RemovalPolicy;

  /**
   * Whether deletion protection should be enabled for the session table.
   * Valid only when session state is enabled.
   * @default undefined (with no naming context: the AWS default, no deletion
   * protection; under a derived naming context: on for a RETAIN table, off otherwise)
   */
  readonly deletionProtection?: boolean;
}

/** One derived MCP OAuth facade route family. */
export interface AppTheoryMcpServerFacadeRoute {
  readonly mcpPattern: string;
  readonly mcpMethods: string[];
  readonly protectedResourcePattern: string;
  readonly discoveryCanonicalPattern: string;
  readonly discoverySuffixPattern: string;
  readonly authorizePattern: string;
  readonly tokenPattern: string;
  readonly registerPattern: string;
  readonly authorizationRoutesAttached: boolean;
}

/** Defensive snapshot of the construct's derived facade inventory. */
export interface AppTheoryMcpServerRouteInventory {
  readonly contractVersion: string;
  readonly routes: AppTheoryMcpServerFacadeRoute[];
  readonly rootAuthorizationServerPattern: string;
  readonly rootAuthorizationServerAttached: boolean;
  readonly callbackPattern: string;
}

/** Props for the AppTheoryMcpServer construct. */
export interface AppTheoryMcpServerProps {
  /** Lambda function handling the runtime-composed MCP facade. */
  readonly handler: lambda.IFunction;

  /**
   * Whether Lambda invoke permissions should be scoped to individual HTTP API v2 routes.
   *
   * When false, the construct grants one API-scoped invoke permission per Lambda instead of
   * one permission per route. This is the scalable choice for large MCP facade families that
   * share one Lambda, where the per-route permissions can exhaust the Lambda resource policy
   * size limit.
   *
   * The trade-off is explicit: the API-scoped permission allows every route on that HTTP API
   * to invoke the handler, not only the routes this construct owns.
   *
   * @default true
   */
  readonly scopePermissionToRoute?: boolean;

  /**
   * Route-emission model.
   *
   * `explicit` (the default) wires the full derived route inventory as one HTTP
   * API v2 route per route key and is byte-stable for deployed stacks.
   * `consolidated` wires exactly two greedy routes, `ANY /` and `ANY /{proxy+}`,
   * and is valid only for the `runtime-bearer` and `none-public` transport
   * postures; `iam` and `jwt` are refused at synthesis.
   *
   * Consolidated mode is allowed on a construct-owned API, or on an attached
   * API that has no routes at attach time. "No routes" is enforced over the
   * whole stack, not just the API's own children: a route wired onto the
   * attached API from any sibling construct scope is refused, because it holds
   * a route key the greedy routes would collide with.
   *
   * A consumer may still add explicit, more specific routes to the consolidated
   * API afterwards, in either the attached or the construct-owned mode. That
   * exception is enforced at synthesis time and is allowed only when the added
   * route carries a non-NONE authorizer and does not redeclare the greedy
   * `ANY /` or `ANY /{proxy+}` key. Within it, a full method+path match beats the
   * greedy routes by API Gateway precedence, and a wrong-method hit on such a
   * path falls to the runtime's fail-closed 404/405.
   * @default AppTheoryMcpRouteModel.EXPLICIT
   */
  readonly routeModel?: AppTheoryMcpRouteModel;

  /**
   * Construct-id derivation for the explicit route model.
   *
   * `legacy` (the default) assigns positional ids in emission order and is
   * byte-stable for deployed stacks. `semantic` derives each id from its route
   * method and pattern, so inserting, removing, or reordering a route family
   * never renames an unrelated route; it is intended for newly created explicit
   * APIs.
   *
   * Switching an existing deployed explicit API from `legacy` to `semantic` in
   * place renames every route in one update, which is exactly the
   * create-before-delete route-key collision the migration check refuses. Adopt
   * `semantic` on an existing stack only through the new-API swap documented in
   * `UPGRADING.md`.
   *
   * This prop applies to `routeModel: explicit` only. The `consolidated` model
   * already emits the two fixed semantic ids `RouteAnyRoot` and `RouteAnyProxy`.
   * @default AppTheoryMcpRouteIdMode.LEGACY
   */
  readonly routeIdMode?: AppTheoryMcpRouteIdMode;

  /**
   * CORS preflight for a construct-owned API. Set to `true` for AppTheory
   * defaults or supply an `AppTheoryHttpApiCorsOptions` object. Invalid in
   * attach mode, where the owning API configures CORS.
   * @default undefined
   */
  readonly cors?: boolean | AppTheoryHttpApiCorsOptions;

  /**
   * Existing HTTP API to attach to. Attach mode is the primary front-door
   * topology and never creates an `AWS::ApiGatewayV2::Api` resource.
   * @default a construct-owned HttpApi
   */
  readonly api?: apigwv2.IHttpApi;

  /**
   * Stage name used when deriving attach-mode execute-api endpoint templates.
   * Use `$default` for the API Gateway default stage. When omitted, the stage
   * is not determinable and the templates retain the bare execute-api origin.
   * This prop does not create, import, or mutate a stage.
   * @default undefined
   */
  readonly attachedApiStageName?: string;

  /**
   * Ordered MCP route family.
   *
   * Go `runtime/mcpfacade.RegisterMCPFacade` serves only the canonical default
   * family. Noncanonical patterns require app-owned runtime route registration
   * that matches the construct's `routeInventory`.
   * @default AppTheoryMcpRouteAlgebra.supportedEndpointTemplates()
   */
  readonly routeFamily?: AppTheoryMcpRouteFamily;

  /**
   * Transport-route authorization posture.
   *
   * An explicit selection overrides the facade-scoped default. When it is
   * omitted, a server that attaches `facade` resolves to `runtime-bearer` and a
   * plain transport server resolves to `iam`. `none-public` is never a default
   * and carries the defense-in-depth floor.
   * @default AppTheoryMcpTransportPosture.RUNTIME_BEARER when `facade` is attached, otherwise AppTheoryMcpTransportPosture.IAM
   */
  readonly transportPosture?: AppTheoryMcpTransportPosture;

  /**
   * Upstream-provider attachment that marks this server as facade-configured.
   *
   * The attachment's presence selects the `runtime-bearer` posture default.
   * Provider wiring lands in M3; this milestone validates the attachment shape.
   * @default undefined
   */
  readonly facade?: AppTheoryMcpFacadeAttachment;

  /**
   * Runtime-side RFC 9728 bearer validation declaration.
   *
   * Required by `transportPosture: RUNTIME_BEARER` and refused under every
   * other posture.
   * @default undefined
   */
  readonly runtimePosture?: AppTheoryMcpRuntimePostureOptions;

  /**
   * Direct-origin reachability decision required under RUNTIME_BEARER and
   * NONE_PUBLIC. A directly reachable origin is refused unless it is declared
   * `FRONTED`, which requires `frontDoorVerification`.
   * @default undefined
   */
  readonly originReachability?: AppTheoryMcpOriginReachability;

  /**
   * Front-door verification declaration, required with
   * `originReachability: FRONTED` and refused under every other decision.
   *
   * The construct records the posture, the header name, and either a SHA-256
   * digest of the declared literal or the well-known parameter name in the
   * `apptheory:mcp-transport-posture` metadata; it never emits the secret
   * value. `frontDoorOriginHeader` is the origin custom header the application
   * wires, and for the parameter form its value is a CloudFormation dynamic
   * reference. Enforcement is the runtime's front-door header check, so an
   * unwired runtime enforces nothing.
   * @default undefined
   */
  readonly frontDoorVerification?: AppTheoryMcpFrontDoorVerificationOptions;

  /**
   * Denial-telemetry declaration required under RUNTIME_BEARER only.
   * @default undefined
   */
  readonly denialSignal?: AppTheoryMcpDenialSignalOptions;

  /**
   * Attach-mode record of the owning API's throttling and access-logging
   * decisions, required under RUNTIME_BEARER and NONE_PUBLIC.
   * @default undefined
   */
  readonly owningApiDefense?: AppTheoryMcpOwningApiDefenseOptions;

  /**
   * Static JWT configuration for the MCP transport routes.
   *
   * Transport routes are the POST, GET, and DELETE routes on every MCP pattern.
   * This prop is only valid with `transportPosture: JWT`, which requires an
   * issuer and a non-empty audience. Discovery, protected-resource metadata,
   * authorize, and token routes remain explicitly public (`NONE`) because OAuth
   * clients must fetch them before they hold a token.
   * @default undefined
   */
  readonly transportAuthorizer?: AppTheoryMcpTransportAuthorizerOptions;

  /**
   * Stage-global upstream OAuth callback path.
   *
   * The CDK-mounted callback route and the runtime-registered one must not
   * diverge: this prop is resolved by
   * `AppTheoryMcpRouteAlgebra.callbackPathForConfiguredPath`, the same algebra
   * the runtime applies to `FacadeConfig.UpstreamCallbackPath`. Supply a
   * synthesis-time literal absolute path with no query, fragment, or dot
   * segment; an empty value keeps the contract default, and a value that
   * collides with another derived route fails synthesis. Refused under
   * `transportPosture: none-public`, which attaches no OAuth surface.
   * @default AppTheoryMcpRouteAlgebra.DEFAULT_CALLBACK_PATH
   */
  readonly upstreamCallbackPath?: string;

  /**
   * Session-state table configuration. The table defaults on.
   * @default enabled with production defaults
   */
  readonly sessionState?: AppTheoryMcpSessionStateOptions;

  /**
   * Owned-API configuration for standalone mode. Invalid with `api`.
   * @default production-owned API defaults
   */
  readonly ownedApi?: AppTheoryMcpServerOwnedApiOptions;

  /**
   * Single MCP route path from the v3.1.x A6 surface.
   * @deprecated Use `routeFamily.patterns`. The new default is the canonical
   * four-pattern family; use `{ patterns: ['/mcp'] }` for the old singleton.
   */
  readonly mcpPath?: string;

  /**
   * Authorization-server issuer from the v3.1.x A6 environment contract.
   * @deprecated Configure `runtime/mcpfacade.FacadeConfig.IssuerURL` in the
   * application. The construct no longer injects issuer environment values.
   */
  readonly authorizationServerIssuer?: string;

  /**
   * JWKS URI from the v3.1.x A6 environment contract.
   * @deprecated Configure `runtime/mcpfacade.FacadeConfig.JWKSURI` in the
   * application. The construct no longer injects JWKS environment values.
   */
  readonly jwksUri?: string;

  /** @deprecated Use `ownedApi.apiName`. */
  readonly apiName?: string;

  /**
   * Optional naming and logging context for the owned HTTP API.
   *
   * With the standard logging profile the access log group is named
   * `logs/access/api/{logicalName}` and carries the contract's JSON field set.
   * Access logging already defaults on; pass `ownedApi.stage.accessLogging:
   * false` to opt out. Attach mode ignores this prop.
   *
   * @default undefined
   */
  readonly namingContext?: AppTheoryNamingContext;

  /**
   * The owned API's logical name. Defaults to the kebab-cased construct id when
   * a naming context is present.
   *
   * @default undefined
   */
  readonly logicalName?: string;

  /**
   * @deprecated Use `sessionState.enabled`. Session state now defaults on.
   */
  readonly enableSessionTable?: boolean;

  /** @deprecated Use `sessionState.tableName`. */
  readonly sessionTableName?: string;

  /** @deprecated Use `sessionState.ttlMinutes`. */
  readonly sessionTtlMinutes?: number;

  /**
   * @deprecated Use `ownedApi.domain`. Domains are invalid in attach mode.
   */
  readonly domain?: AppTheoryMcpServerDomainOptions;

  /**
   * @deprecated Use `ownedApi.stage`. Stage options are invalid in attach mode.
   */
  readonly stage?: AppTheoryMcpServerStageOptions;
}

/**
 * Contract-first MCP facade deployment construct.
 *
 * The primary mode attaches the complete route-algebra family to a supplied
 * HTTP API. Omitting `api` specializes the same path into a standalone owned
 * API. The construct routes only: OAuth metadata, scopes, capabilities, and
 * authorize/token behavior remain application-owned through Go
 * `mcpfacade.RegisterMCPFacade`.
 */
export class AppTheoryMcpServer extends Construct {
  private routeSequence = 0;
  private routeIdMode = AppTheoryMcpRouteIdMode.LEGACY;
  private readonly routeIds = new Set<string>();

  public readonly api: apigwv2.IHttpApi;
  public readonly ownedApi?: apigwv2.HttpApi;
  public readonly sessionTable?: dynamodb.ITable;
  /**
   * Resolved transport-route authorization posture.
   *
   * Facade-configured servers resolve to `runtime-bearer` unless
   * `transportPosture` overrides the default; plain transport servers resolve
   * to `iam`. Deliberately public servers must select `none-public` explicitly.
   */
  public readonly transportPosture: AppTheoryMcpTransportPosture;
  /**
   * Derived endpoint templates for the ordered MCP route family.
   *
   * In attach mode these are execute-api origin templates, not declarations of
   * public authority. An `apiEndpoint` supplied through
   * `HttpApi.fromHttpApiAttributes` is never consulted; the origin is derived
   * from `apiId`, the stack region and URL suffix, plus
   * `attachedApiStageName` when supplied.
   */
  public readonly endpoints: string[];
  public readonly mcpPaths: string[];
  public readonly protectedResourceMetadataPaths: string[];
  public readonly routeInventory: AppTheoryMcpServerRouteInventory;

  /**
   * First derived endpoint template.
   *
   * In attach mode an `apiEndpoint` supplied through
   * `HttpApi.fromHttpApiAttributes` is never consulted. This value is an
   * execute-api origin template derived by the same rules as `endpoints`, not
   * the front door's public authority.
   * @deprecated Use `endpoints`.
   */
  public readonly endpoint: string;

  /** @deprecated Use `mcpPaths`. */
  public readonly mcpPath: string;

  /** @deprecated Use `protectedResourceMetadataPaths` or `routeInventory`. */
  public readonly protectedResourceMetadataPath: string;

  public readonly domainName?: apigwv2.DomainName;
  public readonly apiMapping?: apigwv2.ApiMapping;
  public readonly cnameRecord?: route53.CnameRecord;
  public readonly accessLogGroup?: logs.ILogGroup;

  /**
   * The origin custom header the app-owned front door must send on every origin
   * request, present only under `originReachability: FRONTED`.
   *
   * Wire it into the distribution origin:
   * `origins.HttpOrigin(host, { customHeaders: { [h.headerName]: h.headerValue } })`.
   * Under the parameter form `headerValue` is a `{{resolve:ssm:...}}`
   * CloudFormation dynamic reference, so the value never enters the
   * application source or the construct's template.
   */
  public readonly frontDoorOriginHeader?: AppTheoryMcpFrontDoorHeader;

  constructor(scope: Construct, id: string, props: AppTheoryMcpServerProps) {
    super(scope, id);

    validateOwningMode(props);
    normalizeLegacyAuthConfig(props);
    const routeFamily = normalizeRouteFamily(props);
    const ownedOptions = normalizeOwnedApiOptions(props);

    const posture = props.transportPosture
      ?? (props.facade !== undefined
        ? AppTheoryMcpTransportPosture.RUNTIME_BEARER
        : AppTheoryMcpTransportPosture.IAM);
    validateTransportPosture(posture);
    validateFacadeAttachment(props.facade);
    validatePostureGuards(props, routeFamily, posture);
    validateDefenseInDepth(props, posture, ownedOptions);
    const originReachability = resolveOriginReachability(this, props, ownedOptions);
    if (originReachability === AppTheoryMcpOriginReachability.FRONTED) {
      (this as { frontDoorOriginHeader?: AppTheoryMcpFrontDoorHeader }).frontDoorOriginHeader =
        frontDoorOriginHeader(props.frontDoorVerification);
      grantFrontDoorParameterRead(this, props.handler, props.frontDoorVerification);
    }
    const routeModel = resolveRouteModel(props);
    validateRouteModelPosture(routeModel, posture);
    const routeIdMode = resolveRouteIdMode(props);
    this.routeIdMode = routeIdMode;
    if (routeModel === AppTheoryMcpRouteModel.CONSOLIDATED && props.api !== undefined) {
      assertConsolidatedAttachAllowed(this, props.api);
    }
    const authorizationRoutesAttached = posture !== AppTheoryMcpTransportPosture.NONE_PUBLIC;
    const upstreamCallbackPath = resolveUpstreamCallbackPath(props);

    this.transportPosture = posture;
    this.mcpPaths = [...routeFamily.patterns];
    this.routeInventory = buildRouteInventory(
      this.mcpPaths,
      authorizationRoutesAttached,
      routeFamily.rootAuthorizationServerDiscovery,
      upstreamCallbackPath,
    );
    validateRouteInventory(this.routeInventory, authorizationRoutesAttached);
    this.protectedResourceMetadataPaths = this.routeInventory.routes.map(
      (route) => route.protectedResourcePattern,
    );
    this.mcpPath = this.mcpPaths[0];
    this.protectedResourceMetadataPath = this.protectedResourceMetadataPaths[0];

    let ownedStage: apigwv2.IStage | undefined;
    let ownedStageName = "$default";
    if (props.api) {
      this.api = props.api;
    } else {
      const stageOptions = normalizeStageOptions(ownedOptions.stage);
      ownedStageName = stageOptions.stageName;
      const namingContext = props.namingContext;
      const logical = props.logicalName ?? (namingContext ? defaultLogicalName(this) : undefined);
      const standard = namingContext?.standardLogging === true;
      const apiNameProp = props.ownedApi?.apiName !== undefined ? "ownedApi.apiName" : "apiName";
      refuseExplicitName(namingContext, "AppTheoryMcpServer", apiNameProp, "api_http", logical, ownedOptions.apiName !== undefined);
      refuseExplicitName(
        namingContext,
        "AppTheoryMcpServer",
        "sessionState.tableName",
        "dynamodb_table",
        logical ? `${logical}-sessions` : undefined,
        props.sessionState?.tableName !== undefined || props.sessionTableName !== undefined,
      );
      const derivedApiName = namingContext && logical ? namingContext.physicalName("api_http", logical) : undefined;
      const api = new apigwv2.HttpApi(this, "Api", {
        apiName: derivedApiName && !derivedApiName.generated ? derivedApiName.name : ownedOptions.apiName,
        corsPreflight: buildCorsPreflight(props.cors),
        createDefaultStage: false,
        disableExecuteApiEndpoint: originReachability === AppTheoryMcpOriginReachability.DISABLED
          || originReachability === AppTheoryMcpOriginReachability.LOCKED
          ? true
          : undefined,
      });
      (this as { ownedApi?: apigwv2.HttpApi }).ownedApi = api;
      this.api = api;
      if (originReachability === AppTheoryMcpOriginReachability.DISABLED) {
        registerOwnedDisabledOriginValidation(this, api);
      }

      const stage = new apigwv2.HttpStage(this, "Stage", {
        httpApi: api,
        stageName: stageOptions.stageName,
        autoDeploy: true,
        throttle: stageOptions.throttlingEnabled
          ? {
            rateLimit: stageOptions.throttlingRateLimit,
            burstLimit: stageOptions.throttlingBurstLimit,
          }
          : undefined,
      });
      ownedStage = stage;

      if (stageOptions.accessLogging) {
        if (standard && !logical) {
          throw new Error("AppTheoryMcpServer standard logging requires a logical name");
        }
        // The construct-created access-log group is a logging resource: under
        // the standard profile it takes the contract log-source name, and under
        // the legacy profile it keeps today's CloudFormation-generated name and
        // consumes no naming entry (r3, ADV-1312-1).
        const logGroup = standard && namingContext && logical
          ? new logs.LogGroup(this, "AccessLogs", {
              logGroupName: namingContext.logGroupName(`logs/access/api/${logical}`),
              retention: retentionFor(namingContext.retentionDays),
            })
          : new logs.LogGroup(this, "AccessLogs", {
              retention: stageOptions.accessLogRetention,
            });
        (this as { accessLogGroup?: logs.ILogGroup }).accessLogGroup = logGroup;
        const cfnStage = stage.node.defaultChild as apigwv2.CfnStage;
        cfnStage.accessLogSettings = {
          destinationArn: logGroup.logGroupArn,
          format: standard ? httpApiAccessLogFormat() : accessLogFormat(),
        };
      }
    }

    const integration = new apigwv2Integrations.HttpLambdaIntegration(
      "McpHandler",
      props.handler,
      {
        payloadFormatVersion: apigwv2.PayloadFormatVersion.VERSION_2_0,
        scopePermissionToRoute: props.scopePermissionToRoute ?? true,
      },
    );
    const transportAuthorizer = resolveTransportAuthorizer(props, posture);
    let firstTransportRoute: apigwv2.HttpRoute | undefined;
    if (routeModel === AppTheoryMcpRouteModel.CONSOLIDATED) {
      firstTransportRoute = this.addConsolidatedRoute(
        CONSOLIDATED_ROOT_ROUTE_ID,
        "/",
        integration,
        transportAuthorizer,
      );
      const proxyRoute = this.addConsolidatedRoute(
        CONSOLIDATED_PROXY_ROUTE_ID,
        "/{proxy+}",
        integration,
        transportAuthorizer,
      );
      registerConsolidatedAttachValidation(this, this.api, [firstTransportRoute, proxyRoute]);
    } else {
      const runtimeOwnedAuth = new apigwv2.HttpNoneAuthorizer();
      for (const route of this.routeInventory.routes) {
        for (const method of route.mcpMethods) {
          const created = this.addRuntimeRoute(
            route.mcpPattern,
            toHttpMethod(method),
            integration,
            transportAuthorizer,
          );
          firstTransportRoute = firstTransportRoute ?? created;
        }
        if (authorizationRoutesAttached) {
          this.addRuntimeRoute(route.protectedResourcePattern, apigwv2.HttpMethod.GET, integration, runtimeOwnedAuth);
          this.addRuntimeRoute(route.discoveryCanonicalPattern, apigwv2.HttpMethod.GET, integration, runtimeOwnedAuth);
          this.addRuntimeRoute(route.discoverySuffixPattern, apigwv2.HttpMethod.GET, integration, runtimeOwnedAuth);
          this.addRuntimeRoute(route.authorizePattern, apigwv2.HttpMethod.GET, integration, runtimeOwnedAuth);
          this.addRuntimeRoute(route.tokenPattern, apigwv2.HttpMethod.POST, integration, runtimeOwnedAuth);
          this.addRuntimeRoute(route.registerPattern, apigwv2.HttpMethod.POST, integration, runtimeOwnedAuth);
        }
      }
      // The upstream callback is stage-global, not per kind: wire it exactly once.
      if (authorizationRoutesAttached) {
        this.addRuntimeRoute(
          this.routeInventory.callbackPattern,
          apigwv2.HttpMethod.GET,
          integration,
          runtimeOwnedAuth,
        );
      }
      if (this.routeInventory.rootAuthorizationServerAttached) {
        this.addRuntimeRoute(
          this.routeInventory.rootAuthorizationServerPattern,
          apigwv2.HttpMethod.GET,
          integration,
          runtimeOwnedAuth,
        );
      }
    }

    const postureMarkerTarget = (this.ownedApi?.node.defaultChild
      ?? firstTransportRoute?.node.defaultChild) as apigwv2.CfnApi | apigwv2.CfnRoute | undefined;
    postureMarkerTarget?.addMetadata(MCP_TRANSPORT_POSTURE_METADATA_KEY, {
      posture,
      contract_id: MCP_TRANSPORT_POSTURE_CONTRACT_ID,
      route_count: this.routeInventory.routes.length,
      runtime_posture_declared: props.runtimePosture !== undefined,
      // Only a FRONTED decision extends the marker, so DISABLED and LOCKED
      // templates stay byte-identical. The literal secret is consumed here for
      // its digest and never emitted.
      ...(originReachability === AppTheoryMcpOriginReachability.FRONTED
        ? frontDoorPostureMetadata(props.frontDoorVerification)
        : {}),
    });

    const sessionState = normalizeSessionState(props);
    if (sessionState.enabled) {
      // Only an owned API derives the session-table name. The secure-default
      // decision is separate: an attached API still receives the deletion
      // protection (DynamoDB.6) that the AppTheory-created table needs.
      const sessionNamingContext = props.api ? undefined : props.namingContext;
      const logical = sessionNamingContext
        ? props.logicalName ?? defaultLogicalName(this)
        : undefined;
      const derivedTableName = sessionNamingContext && logical
        ? sessionNamingContext.physicalName("dynamodb_table", `${logical}-sessions`)
        : undefined;
      const table = new dynamodb.Table(this, "SessionTable", {
        tableName: derivedTableName && !derivedTableName.generated ? derivedTableName.name : sessionState.tableName,
        billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
        partitionKey: { name: "sessionId", type: dynamodb.AttributeType.STRING },
        timeToLiveAttribute: "expiresAt",
        removalPolicy: sessionState.removalPolicy,
        deletionProtection: defaultDeletionProtection(
          props.namingContext,
          sessionState.removalPolicy,
          sessionState.deletionProtection,
        ),
        pointInTimeRecoverySpecification: { pointInTimeRecoveryEnabled: true },
        encryption: dynamodb.TableEncryption.AWS_MANAGED,
      });
      table.grantReadWriteData(props.handler);
      this.sessionTable = table;
      this.addEnvironment(props.handler, "MCP_SESSION_TABLE", table.tableName);
      this.addEnvironment(props.handler, "MCP_SESSION_TTL_MINUTES", String(sessionState.ttlMinutes));
    }

    let endpointBase: string;
    if (ownedOptions.domain) {
      if (!ownedStage) {
        throw new Error("AppTheoryMcpServer: domain configuration requires construct-owned API mode");
      }
      this.setupCustomDomain(ownedOptions.domain, ownedStage, props.api ? undefined : props.namingContext);
      if (
        originReachability === AppTheoryMcpOriginReachability.LOCKED
        && this.ownedApi !== undefined
      ) {
        registerOwnedLockedOriginValidation(this, this.ownedApi);
      }
      endpointBase = `https://${ownedOptions.domain.domainName}`;
    } else if (props.api) {
      const stack = Stack.of(this);
      const executeApiOrigin = `https://${this.api.apiId}.execute-api.${stack.region}.${stack.urlSuffix}`;
      endpointBase = props.attachedApiStageName === undefined || props.attachedApiStageName === "$default"
        ? executeApiOrigin
        : `${executeApiOrigin}/${props.attachedApiStageName}`;
    } else {
      endpointBase = ownedStageName === "$default"
        ? this.api.apiEndpoint
        : `${this.api.apiEndpoint}/${ownedStageName}`;
    }
    this.endpoints = this.mcpPaths.map(
      (pattern) => `${stripTrailingSlash(endpointBase)}${pattern}`,
    );
    if (
      props.api === undefined
      && (originReachability === AppTheoryMcpOriginReachability.DISABLED
        || originReachability === AppTheoryMcpOriginReachability.LOCKED)
      && this.endpoints.some((endpoint) => endpoint.includes(".execute-api."))
    ) {
      throw new Error(
        "AppTheoryMcpServer: originReachability DISABLED must advertise the owned custom domain, never the disabled execute-api endpoint",
      );
    }
    this.endpoint = this.endpoints[0];
  }

  private addRuntimeRoute(
    path: string,
    method: apigwv2.HttpMethod,
    integration: apigwv2Integrations.HttpLambdaIntegration,
    authorizer: apigwv2.IHttpRouteAuthorizer,
  ): apigwv2.HttpRoute {
    return new apigwv2.HttpRoute(this, this.nextRouteConstructId(method, path), {
      httpApi: this.api,
      routeKey: apigwv2.HttpRouteKey.with(path, method),
      integration,
      authorizer,
    });
  }

  private nextRouteConstructId(method: apigwv2.HttpMethod, path: string): string {
    if (this.routeIdMode !== AppTheoryMcpRouteIdMode.SEMANTIC) {
      return `Route${this.routeSequence++}`;
    }
    const id = semanticRouteConstructId(method, path);
    if (this.routeIds.has(id)) {
      throw new Error(
        `AppTheoryMcpServer: routeIdMode semantic derives the duplicate route construct id ${id} for route key ${method} ${path}`,
      );
    }
    this.routeIds.add(id);
    return id;
  }

  private addConsolidatedRoute(
    id: string,
    path: string,
    integration: apigwv2Integrations.HttpLambdaIntegration,
    authorizer: apigwv2.IHttpRouteAuthorizer,
  ): apigwv2.HttpRoute {
    return new apigwv2.HttpRoute(this, id, {
      httpApi: this.api,
      routeKey: apigwv2.HttpRouteKey.with(path, apigwv2.HttpMethod.ANY),
      integration,
      authorizer,
    });
  }

  private addEnvironment(handler: lambda.IFunction, key: string, value: string): void {
    if ("addEnvironment" in handler && typeof handler.addEnvironment === "function") {
      handler.addEnvironment(key, value);
    }
  }

  private setupCustomDomain(
    options: AppTheoryMcpServerDomainOptions,
    stage: apigwv2.IStage,
    namingContext?: AppTheoryNamingContext,
  ): void {
    const certificate = options.certificate ?? (options.certificateArn
      ? acm.Certificate.fromCertificateArn(this, "ImportedCert", options.certificateArn) as acm.ICertificate
      : undefined);
    if (!certificate) {
      throw new Error(
        "AppTheoryMcpServer: ownedApi.domain requires either certificate or certificateArn",
      );
    }
    const domainName = new apigwv2.DomainName(this, "DomainName", {
      domainName: options.domainName,
      certificate,
      mtls: options.mutualTlsAuthentication,
      securityPolicy: options.securityPolicy
        ?? (secureDefaults(namingContext) ? RECOMMENDED_HTTP_API_SECURITY_POLICY : undefined),
    });
    (this as { domainName?: apigwv2.DomainName }).domainName = domainName;
    const apiMapping = new apigwv2.ApiMapping(this, "ApiMapping", {
      api: this.api,
      domainName,
      stage,
    });
    (this as { apiMapping?: apigwv2.ApiMapping }).apiMapping = apiMapping;
    if (options.hostedZone) {
      const cnameRecord = new route53.CnameRecord(this, "CnameRecord", {
        zone: options.hostedZone,
        recordName: toRoute53RecordName(options.domainName, options.hostedZone),
        domainName: domainName.regionalDomainName,
      });
      (this as { cnameRecord?: route53.CnameRecord }).cnameRecord = cnameRecord;
    }
  }
}

interface NormalizedRouteFamily {
  readonly patterns: string[];
  readonly rootAuthorizationServerDiscovery: boolean;
}

interface NormalizedOwnedApiOptions {
  readonly apiName?: string;
  readonly domain?: AppTheoryMcpServerDomainOptions;
  readonly stage?: AppTheoryMcpServerStageOptions;
}

interface NormalizedStageOptions {
  readonly stageName: string;
  readonly accessLogging: boolean;
  readonly accessLogRetention: logs.RetentionDays;
  readonly throttlingEnabled: boolean;
  readonly throttlingRateLimit: number;
  readonly throttlingBurstLimit: number;
}

interface NormalizedSessionState {
  readonly enabled: boolean;
  readonly tableName?: string;
  readonly ttlMinutes: number;
  readonly removalPolicy: RemovalPolicy;
  readonly deletionProtection?: boolean;
}

function normalizeRouteFamily(props: AppTheoryMcpServerProps): NormalizedRouteFamily {
  if (props.routeFamily !== undefined && props.mcpPath !== undefined) {
    throw new Error(
      "AppTheoryMcpServer: routeFamily and deprecated mcpPath cannot be supplied together",
    );
  }
  const rawPatterns = props.routeFamily?.patterns
    ?? (props.mcpPath !== undefined
      ? [props.mcpPath]
      : AppTheoryMcpRouteAlgebra.supportedEndpointTemplates().map(
        (template) => template.mcpPattern,
      ));
  if (rawPatterns.length === 0) {
    throw new Error("AppTheoryMcpServer: routeFamily.patterns must not be empty");
  }
  const patterns = rawPatterns.map((pattern, index) =>
    normalizeRoutePath(pattern, `routeFamily.patterns[${index}]`));
  const seen = new Set<string>();
  for (const pattern of patterns) {
    if (seen.has(pattern)) {
      throw new Error(
        `AppTheoryMcpServer: routeFamily.patterns contains duplicate pattern ${JSON.stringify(pattern)}`,
      );
    }
    seen.add(pattern);
  }
  return {
    patterns,
    rootAuthorizationServerDiscovery:
      props.routeFamily?.rootAuthorizationServerDiscovery ?? false,
  };
}

function normalizeRoutePath(value: string, propName: string): string {
  if (Token.isUnresolved(value)) {
    throw new Error(
      `AppTheoryMcpServer: ${propName} must be a synthesis-time literal route pattern`,
    );
  }
  const routePath = String(value ?? "");
  if (!routePath.startsWith("/")) throw invalidRoutePattern(propName);
  const segments = routePath.slice(1).split("/");
  if (segments.length === 0 || segments.some((segment) => segment === "")) {
    throw invalidRoutePattern(propName);
  }
  const literal = /^(?:[A-Za-z0-9._~!$&'()*+,;=:@-]|%[0-9A-Fa-f]{2})+$/;
  const parameter = /^\{([A-Za-z_][A-Za-z0-9_]*)\}$/;
  for (const segment of segments) {
    if (segment === "." || segment === "..") throw invalidRoutePattern(propName);
    if (parameter.test(segment)) continue;
    if (!literal.test(segment) || segment.includes("{") || segment.includes("}")) {
      throw invalidRoutePattern(propName);
    }
  }
  return routePath;
}

function invalidRoutePattern(propName: string): Error {
  return new Error(
    `AppTheoryMcpServer: ${propName} must be an absolute synthesis-time route pattern with non-empty literal or {parameter_name} segments and no dot segments`,
  );
}

function resolveUpstreamCallbackPath(props: AppTheoryMcpServerProps): string {
  const configured = props.upstreamCallbackPath;
  if (configured === undefined) {
    return AppTheoryMcpRouteAlgebra.DEFAULT_CALLBACK_PATH;
  }
  if (Token.isUnresolved(configured)) {
    throw new Error(
      "AppTheoryMcpServer: upstreamCallbackPath must be a synthesis-time literal route path",
    );
  }
  try {
    return AppTheoryMcpRouteAlgebra.callbackPathForConfiguredPath(configured);
  } catch (err) {
    const reason = err instanceof Error
      ? err.message.replace(/^mcproutes: /, "")
      : String(err);
    throw new Error(
      `AppTheoryMcpServer: upstreamCallbackPath is invalid: ${reason}`,
    );
  }
}

function buildRouteInventory(
  patterns: string[],
  authorizationRoutesAttached: boolean,
  rootAuthorizationServerAttached: boolean,
  callbackPattern: string,
): AppTheoryMcpServerRouteInventory {
  return {
    contractVersion: AppTheoryMcpRouteAlgebra.CONTRACT_VERSION,
    routes: patterns.map((mcpPattern) => ({
      mcpPattern,
      mcpMethods: ["POST", "GET", "DELETE"],
      protectedResourcePattern:
        AppTheoryMcpRouteAlgebra.protectedResourcePathForResourcePath(mcpPattern),
      discoveryCanonicalPattern:
        AppTheoryMcpRouteAlgebra.authorizationServerPathForResourcePath(mcpPattern),
      discoverySuffixPattern:
        AppTheoryMcpRouteAlgebra.authorizationServerSuffixPathForResourcePath(mcpPattern),
      authorizePattern:
        AppTheoryMcpRouteAlgebra.authorizationAuthorizePathForResourcePath(mcpPattern),
      tokenPattern:
        AppTheoryMcpRouteAlgebra.authorizationTokenPathForResourcePath(mcpPattern),
      registerPattern:
        AppTheoryMcpRouteAlgebra.authorizationRegisterPathForResourcePath(mcpPattern),
      authorizationRoutesAttached,
    })),
    rootAuthorizationServerPattern:
      AppTheoryMcpRouteAlgebra.authorizationServerPathForResourcePath("/"),
    rootAuthorizationServerAttached,
    callbackPattern,
  };
}

function validateRouteInventory(
  inventory: AppTheoryMcpServerRouteInventory,
  authorizationRoutesAttached: boolean,
): void {
  const seen = new Set<string>();
  const add = (method: string, path: string): void => {
    const key = `${method} ${path}`;
    if (seen.has(key)) {
      throw new Error(`AppTheoryMcpServer: derived route family collides at ${key}`);
    }
    seen.add(key);
  };
  for (const route of inventory.routes) {
    for (const method of route.mcpMethods) add(method, route.mcpPattern);
    if (authorizationRoutesAttached) {
      add("GET", route.protectedResourcePattern);
      add("GET", route.discoveryCanonicalPattern);
      add("GET", route.discoverySuffixPattern);
      add("GET", route.authorizePattern);
      add("POST", route.tokenPattern);
      add("POST", route.registerPattern);
    }
  }
  if (authorizationRoutesAttached) {
    add("GET", inventory.callbackPattern);
  }
  if (inventory.rootAuthorizationServerAttached) {
    add("GET", inventory.rootAuthorizationServerPattern);
  }
}

function validateOwningMode(props: AppTheoryMcpServerProps): void {
  if (!props.api) {
    if (props.attachedApiStageName !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: attachedApiStageName requires attach mode with api",
      );
    }
    return;
  }
  if (
    props.attachedApiStageName !== undefined
    && (Token.isUnresolved(props.attachedApiStageName)
      || !/^(?:\$default|[A-Za-z0-9_-]{1,128})$/.test(props.attachedApiStageName))
  ) {
    throw new Error(
      "AppTheoryMcpServer: attachedApiStageName must be a synthesis-time literal API Gateway stage name",
    );
  }
  const invalid: string[] = [];
  if (props.ownedApi !== undefined) invalid.push("ownedApi");
  if (props.apiName !== undefined) invalid.push("apiName");
  if (props.cors !== undefined) invalid.push("cors");
  if (props.domain !== undefined) invalid.push("domain");
  if (props.stage !== undefined) invalid.push("stage");
  if (invalid.length !== 0) {
    throw new Error(
      `AppTheoryMcpServer: attach mode with api cannot configure owned-API props: ${invalid.join(", ")}`,
    );
  }
}

function normalizeOwnedApiOptions(props: AppTheoryMcpServerProps): NormalizedOwnedApiOptions {
  if (props.ownedApi?.apiName !== undefined && props.apiName !== undefined) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.apiName and deprecated apiName cannot be supplied together",
    );
  }
  if (props.ownedApi?.domain !== undefined && props.domain !== undefined) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.domain and deprecated domain cannot be supplied together",
    );
  }
  if (props.ownedApi?.stage !== undefined && props.stage !== undefined) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.stage and deprecated stage cannot be supplied together",
    );
  }
  return {
    apiName: props.ownedApi?.apiName ?? props.apiName,
    domain: props.ownedApi?.domain ?? props.domain,
    stage: props.ownedApi?.stage ?? props.stage,
  };
}

function normalizeStageOptions(options?: AppTheoryMcpServerStageOptions): NormalizedStageOptions {
  const accessLogging = options?.accessLogging ?? true;
  if (!accessLogging && options?.accessLogRetention !== undefined) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.stage.accessLogRetention requires accessLogging to be enabled",
    );
  }
  const throttlingEnabled = options?.throttlingEnabled ?? true;
  if (
    !throttlingEnabled
    && (options?.throttlingRateLimit !== undefined || options?.throttlingBurstLimit !== undefined)
  ) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.stage throttling limits require throttlingEnabled to be true",
    );
  }
  const rateLimit = options?.throttlingRateLimit ?? DEFAULT_THROTTLING_RATE_LIMIT;
  const burstLimit = options?.throttlingBurstLimit ?? DEFAULT_THROTTLING_BURST_LIMIT;
  validatePositiveNumber(rateLimit, "ownedApi.stage.throttlingRateLimit");
  validatePositiveNumber(burstLimit, "ownedApi.stage.throttlingBurstLimit");
  return {
    stageName: options?.stageName ?? "$default",
    accessLogging,
    accessLogRetention: options?.accessLogRetention ?? logs.RetentionDays.ONE_MONTH,
    throttlingEnabled,
    throttlingRateLimit: rateLimit,
    throttlingBurstLimit: burstLimit,
  };
}

function normalizeSessionState(props: AppTheoryMcpServerProps): NormalizedSessionState {
  const hasLegacy = props.enableSessionTable !== undefined
    || props.sessionTableName !== undefined
    || props.sessionTtlMinutes !== undefined;
  if (props.sessionState !== undefined && hasLegacy) {
    throw new Error(
      "AppTheoryMcpServer: sessionState cannot be combined with deprecated session-table props",
    );
  }
  const enabled = props.sessionState?.enabled ?? props.enableSessionTable ?? true;
  const tableName = props.sessionState?.tableName ?? props.sessionTableName;
  const ttlMinutes = props.sessionState?.ttlMinutes
    ?? props.sessionTtlMinutes
    ?? DEFAULT_SESSION_TTL_MINUTES;
  const removalPolicy = props.sessionState?.removalPolicy ?? RemovalPolicy.RETAIN;
  if (
    !enabled
    && (tableName !== undefined
      || props.sessionState?.ttlMinutes !== undefined
      || props.sessionState?.removalPolicy !== undefined
      || props.sessionState?.deletionProtection !== undefined
      || props.sessionTableName !== undefined
      || props.sessionTtlMinutes !== undefined)
  ) {
    throw new Error(
      "AppTheoryMcpServer: disabled session state cannot configure tableName, ttlMinutes, removalPolicy, or deletionProtection",
    );
  }
  validatePositiveInteger(ttlMinutes, "sessionState.ttlMinutes");
  return {
    enabled,
    tableName,
    ttlMinutes,
    removalPolicy,
    deletionProtection: props.sessionState?.deletionProtection,
  };
}

function normalizeLegacyAuthConfig(props: AppTheoryMcpServerProps): void {
  const hasIssuer = props.authorizationServerIssuer !== undefined;
  const hasJwksUri = props.jwksUri !== undefined;
  if (hasIssuer !== hasJwksUri) {
    throw new Error(
      "AppTheoryMcpServer: authorizationServerIssuer and jwksUri must be supplied together",
    );
  }
  if (!hasIssuer || !hasJwksUri) return;
  const issuer = String(props.authorizationServerIssuer);
  const jwksUri = String(props.jwksUri);
  if (!Token.isUnresolved(issuer)) {
    validateLiteralOAuthURL(
      issuer,
      false,
      "authorizationServerIssuer must be an absolute HTTPS URL with no query or fragment",
    );
  }
  if (!Token.isUnresolved(jwksUri)) {
    validateLiteralOAuthURL(
      jwksUri,
      true,
      "jwksUri must be an absolute HTTPS URL with no userinfo or fragment",
    );
  }
}

function resolveTransportAuthorizer(
  props: AppTheoryMcpServerProps,
  posture: AppTheoryMcpTransportPosture,
): apigwv2.IHttpRouteAuthorizer {
  const configured = props.transportAuthorizer;
  switch (posture) {
    case AppTheoryMcpTransportPosture.IAM:
    case AppTheoryMcpTransportPosture.RUNTIME_BEARER:
    case AppTheoryMcpTransportPosture.NONE_PUBLIC: {
      if (configured !== undefined) {
        throw new Error(
          "AppTheoryMcpServer: transportAuthorizer is only valid with transportPosture JWT",
        );
      }
      return posture === AppTheoryMcpTransportPosture.IAM
        ? new apigwv2Authorizers.HttpIamAuthorizer()
        : new apigwv2.HttpNoneAuthorizer();
    }
    case AppTheoryMcpTransportPosture.JWT: {
      const issuer = String(configured?.issuer ?? "").trim();
      if (issuer === "") {
        throw new Error(
          "AppTheoryMcpServer: transportAuthorizer.issuer is required when transportPosture is JWT",
        );
      }
      if (!Token.isUnresolved(issuer)) {
        validateLiteralOAuthURL(
          issuer,
          false,
          "transportAuthorizer.issuer must be an absolute HTTPS URL with no query or fragment",
        );
      }
      const audience = (configured?.audience ?? [])
        .map((value) => String(value).trim())
        .filter((value) => value !== "");
      if (audience.length === 0) {
        throw new Error(
          "AppTheoryMcpServer: transportAuthorizer.audience requires at least one accepted audience when transportPosture is JWT",
        );
      }
      return new apigwv2Authorizers.HttpJwtAuthorizer(
        MCP_TRANSPORT_AUTHORIZER_ID,
        issuer,
        {
          jwtAudience: audience,
          identitySource: configured?.identitySource,
          authorizerName: configured?.authorizerName,
        },
      );
    }
    default:
      throw new Error(
        "AppTheoryMcpServer: transportPosture must be AppTheoryMcpTransportPosture.IAM, .JWT, .RUNTIME_BEARER, or .NONE_PUBLIC",
      );
  }
}

function postureLabel(posture: AppTheoryMcpTransportPosture): string {
  switch (posture) {
    case AppTheoryMcpTransportPosture.IAM: return "IAM";
    case AppTheoryMcpTransportPosture.JWT: return "JWT";
    case AppTheoryMcpTransportPosture.RUNTIME_BEARER: return "RUNTIME_BEARER";
    case AppTheoryMcpTransportPosture.NONE_PUBLIC: return "NONE_PUBLIC";
    default: return String(posture);
  }
}

function validateTransportPosture(posture: AppTheoryMcpTransportPosture): void {
  switch (posture) {
    case AppTheoryMcpTransportPosture.IAM:
    case AppTheoryMcpTransportPosture.JWT:
    case AppTheoryMcpTransportPosture.RUNTIME_BEARER:
    case AppTheoryMcpTransportPosture.NONE_PUBLIC:
      return;
    default:
      throw new Error(
        "AppTheoryMcpServer: transportPosture must be AppTheoryMcpTransportPosture.IAM, .JWT, .RUNTIME_BEARER, or .NONE_PUBLIC",
      );
  }
}

function resolveRouteModel(props: AppTheoryMcpServerProps): AppTheoryMcpRouteModel {
  const configured = props.routeModel;
  if (configured === undefined) {
    return AppTheoryMcpRouteModel.EXPLICIT;
  }
  if (
    configured === AppTheoryMcpRouteModel.EXPLICIT
    || configured === AppTheoryMcpRouteModel.CONSOLIDATED
  ) {
    return configured;
  }
  throw new Error(
    "AppTheoryMcpServer: routeModel must be AppTheoryMcpRouteModel.EXPLICIT or .CONSOLIDATED",
  );
}

function validateRouteModelPosture(
  routeModel: AppTheoryMcpRouteModel,
  posture: AppTheoryMcpTransportPosture,
): void {
  if (
    routeModel === AppTheoryMcpRouteModel.CONSOLIDATED
    && posture !== AppTheoryMcpTransportPosture.RUNTIME_BEARER
    && posture !== AppTheoryMcpTransportPosture.NONE_PUBLIC
  ) {
    throw new Error(
      `AppTheoryMcpServer: routeModel consolidated is only valid for transportPosture RUNTIME_BEARER or NONE_PUBLIC; transportPosture ${postureLabel(posture)} keeps the explicit route model because consolidation must never change gateway admission`,
    );
  }
}

function resolveRouteIdMode(props: AppTheoryMcpServerProps): AppTheoryMcpRouteIdMode {
  const configured = props.routeIdMode;
  if (configured === undefined) {
    return AppTheoryMcpRouteIdMode.LEGACY;
  }
  if (
    configured === AppTheoryMcpRouteIdMode.LEGACY
    || configured === AppTheoryMcpRouteIdMode.SEMANTIC
  ) {
    return configured;
  }
  throw new Error(
    "AppTheoryMcpServer: routeIdMode must be AppTheoryMcpRouteIdMode.LEGACY or .SEMANTIC",
  );
}

/**
 * The two greedy route keys a consolidated model owns. A consumer route that
 * redeclares one of them would make the API reject the update.
 */
const CONSOLIDATED_GREEDY_ROUTE_KEYS = new Set(["ANY /", "ANY /{proxy+}"]);

/**
 * Resolve an `ApiId` (or any template value) to a comparable string, so a
 * `Ref` token and its logical id compare equal across two templates of the same
 * stack.
 */
function comparableApiId(scope: Construct, value: unknown): string {
  return JSON.stringify(Stack.of(scope).resolve(value));
}

/**
 * Every API Gateway v2 route bound to `api`, regardless of which construct
 * scope created it.
 *
 * `api.node.children` only sees routes the API itself (or a child scope)
 * created, which misses the common pattern of a stack-level construct wiring a
 * route onto an attached API. Walking the stack and resolving each `CfnRoute`'s
 * `ApiId` sees both.
 */
function routesBoundToApi(scope: Construct, api: apigwv2.IHttpApi): apigwv2.CfnRoute[] {
  const stack = Stack.of(scope);
  const apiKey = comparableApiId(scope, api.apiId);
  const found: apigwv2.CfnRoute[] = [];
  const visit = (node: Construct): void => {
    if (node instanceof apigwv2.HttpRoute) {
      if (comparableApiId(scope, node.httpApi.apiId) === apiKey) {
        found.push(node.node.defaultChild as apigwv2.CfnRoute);
      }
      // The route's own CfnRoute child is the same route; do not double count.
      return;
    }
    if (node instanceof apigwv2.CfnRoute && comparableApiId(scope, node.apiId) === apiKey) {
      found.push(node);
    }
    for (const child of node.node.children) {
      visit(child);
    }
  };
  visit(stack);
  return found.filter((route) => route !== undefined);
}

/**
 * Refuse a consolidated attach onto an API that already carries routes.
 *
 * The check deliberately walks the whole stack: a route bound to the attached
 * API from a sibling construct scope is just as much a route key the
 * consolidated greedy routes would collide with as one created under the API
 * itself.
 */
function assertConsolidatedAttachAllowed(scope: Construct, api: apigwv2.IHttpApi): void {
  const existingRoutes = routesBoundToApi(scope, api);
  if (existingRoutes.length > 0) {
    throw new Error(
      "AppTheoryMcpServer: routeModel consolidated may attach only to an API that has no routes at attach time; "
      + `the API already carries ${existingRoutes.length} route(s): ${existingRoutes.map((route) => route.node.path).join(", ")}; `
      + "attach to a new or empty API, or use routeModel explicit",
    );
  }
}

/**
 * Register the synth-time rule for routes added to a consolidated API after
 * the construct created its greedy routes.
 *
 * The rule applies in both consolidated modes: an API the construct attached
 * to, and one the construct owns. The documented exception is what makes
 * consolidated routes usable in a real front door: a consumer may add
 * explicit, more specific routes afterwards. It is allowed only when the
 * route carries a non-NONE authorizer (so the greedy routes never silently
 * widen a stricter posture) and does not redeclare a greedy route key (which
 * API Gateway would reject as a duplicate).
 */
function registerConsolidatedAttachValidation(
  scope: Construct,
  api: apigwv2.IHttpApi,
  ownedRoutes: apigwv2.HttpRoute[],
): void {
  const owned = new Set(
    ownedRoutes.map((route) => route.node.defaultChild as apigwv2.CfnRoute),
  );
  Stack.of(scope).node.addValidation({
    validate: () => {
      const errors: string[] = [];
      for (const route of routesBoundToApi(scope, api)) {
        if (owned.has(route)) {
          continue;
        }
        const routeKey = route.routeKey;
        if (CONSOLIDATED_GREEDY_ROUTE_KEYS.has(routeKey)) {
          errors.push(
            `AppTheoryMcpServer: routeModel consolidated already owns the greedy API Gateway route key ${JSON.stringify(routeKey)} on this API; a route added after construction must not redeclare it (${route.node.path})`,
          );
          continue;
        }
        const authorizationType = String(route.authorizationType ?? "NONE").toUpperCase();
        if (authorizationType === "NONE") {
          errors.push(
            `AppTheoryMcpServer: a route added to a consolidated API after construction must carry a non-NONE authorizer, because the greedy routes admit every method and path at the gateway (${routeKey} from ${route.node.path})`,
          );
        }
      }
      return errors;
    },
  });
}

function validateFacadeAttachment(facade?: AppTheoryMcpFacadeAttachment): void {
  if (facade === undefined) return;
  const providerId = (facade as { providerId?: unknown })?.providerId;
  if (
    typeof providerId !== "string"
    || providerId.trim() === ""
    || Token.isUnresolved(providerId)
  ) {
    throw new Error(
      "AppTheoryMcpServer: facade.providerId must be a non-empty synthesis-time literal string",
    );
  }
}

function validatePostureGuards(
  props: AppTheoryMcpServerProps,
  routeFamily: NormalizedRouteFamily,
  posture: AppTheoryMcpTransportPosture,
): void {
  if (posture === AppTheoryMcpTransportPosture.NONE_PUBLIC) {
    if (props.authorizationServerIssuer !== undefined || props.jwksUri !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: transportPosture NONE_PUBLIC cannot be combined with authorizationServerIssuer or jwksUri",
      );
    }
    if (routeFamily.rootAuthorizationServerDiscovery) {
      throw new Error(
        "AppTheoryMcpServer: transportPosture NONE_PUBLIC cannot enable rootAuthorizationServerDiscovery",
      );
    }
    if (props.runtimePosture !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: transportPosture NONE_PUBLIC cannot declare runtimePosture",
      );
    }
    if (props.upstreamCallbackPath !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: transportPosture NONE_PUBLIC cannot declare upstreamCallbackPath",
      );
    }
    return;
  }
  if (
    posture !== AppTheoryMcpTransportPosture.RUNTIME_BEARER
    && props.runtimePosture !== undefined
  ) {
    throw new Error(
      `AppTheoryMcpServer: transportPosture ${postureLabel(posture)} cannot declare runtimePosture`,
    );
  }
}

function validateDefenseInDepth(
  props: AppTheoryMcpServerProps,
  posture: AppTheoryMcpTransportPosture,
  owned: NormalizedOwnedApiOptions,
): void {
  if (
    posture !== AppTheoryMcpTransportPosture.RUNTIME_BEARER
    && posture !== AppTheoryMcpTransportPosture.NONE_PUBLIC
  ) {
    return;
  }
  const label = postureLabel(posture);
  if (
    posture === AppTheoryMcpTransportPosture.RUNTIME_BEARER
    && (props.runtimePosture === undefined || props.runtimePosture.requireBearerToken !== true)
  ) {
    throw new Error(
      "AppTheoryMcpServer: transportPosture RUNTIME_BEARER requires runtimePosture.requireBearerToken to be true",
    );
  }
  if (
    props.originReachability !== AppTheoryMcpOriginReachability.DISABLED
    && props.originReachability !== AppTheoryMcpOriginReachability.LOCKED
    && props.originReachability !== AppTheoryMcpOriginReachability.FRONTED
  ) {
    throw new Error(
      `AppTheoryMcpServer: transportPosture ${label} requires originReachability to be AppTheoryMcpOriginReachability.DISABLED, .LOCKED, or .FRONTED`,
    );
  }
  if (props.api !== undefined) {
    validateOwningApiDefense(props.owningApiDefense, label);
  } else {
    if (owned.stage?.throttlingEnabled !== true) {
      throw new Error(
        `AppTheoryMcpServer: transportPosture ${label} requires an explicit ownedApi.stage.throttlingEnabled: true throttling decision`,
      );
    }
    if (owned.stage?.accessLogging === false) {
      throw new Error(
        `AppTheoryMcpServer: transportPosture ${label} requires access logging`,
      );
    }
  }
  if (posture === AppTheoryMcpTransportPosture.RUNTIME_BEARER) {
    validateDenialSignal(props.denialSignal);
  }
}

/**
 * Resolve the declared direct-origin decision to a proven posture.
 *
 * Every supplied value is checked, not only the postures that require the
 * decision. DISABLED needs the owned ordinary domain that replaces the disabled
 * execute-api authority (or a provable concrete attach), and LOCKED
 * additionally needs mutual TLS on every domain mapped to the owned API.
 * Attach-mode LOCKED is unsupported because an external API carries no in-stack
 * truststore or mapping evidence. FRONTED is the attach-mode counterpart for an
 * application-owned front door: it produces no in-stack evidence, so it is
 * accepted only with an explicit, validated `frontDoorVerification` declaration
 * and only in attach mode.
 */
function resolveOriginReachability(
  scope: Construct,
  props: AppTheoryMcpServerProps,
  owned: NormalizedOwnedApiOptions,
): AppTheoryMcpOriginReachability | undefined {
  const decision = props.originReachability;
  const mutualTls = owned.domain?.mutualTlsAuthentication;
  if (decision === undefined) {
    if (mutualTls !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: ownedApi.domain.mutualTlsAuthentication is only valid with originReachability LOCKED",
      );
    }
    if (props.frontDoorVerification !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: frontDoorVerification is only valid with originReachability FRONTED",
      );
    }
    return undefined;
  }
  if (
    decision !== AppTheoryMcpOriginReachability.DISABLED
    && decision !== AppTheoryMcpOriginReachability.LOCKED
    && decision !== AppTheoryMcpOriginReachability.FRONTED
  ) {
    throw new Error(
      "AppTheoryMcpServer: originReachability must be AppTheoryMcpOriginReachability.DISABLED, .LOCKED, or .FRONTED",
    );
  }
  if (mutualTls !== undefined && decision !== AppTheoryMcpOriginReachability.LOCKED) {
    throw new Error(
      "AppTheoryMcpServer: ownedApi.domain.mutualTlsAuthentication is only valid with originReachability LOCKED",
    );
  }
  if (
    decision !== AppTheoryMcpOriginReachability.FRONTED
    && props.frontDoorVerification !== undefined
  ) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification is only valid with originReachability FRONTED",
    );
  }
  if (decision === AppTheoryMcpOriginReachability.FRONTED) {
    if (props.api === undefined) {
      throw new Error(
        "AppTheoryMcpServer: originReachability FRONTED is unsupported in owned mode; an owned front door is wired by the DISABLED or LOCKED posture",
      );
    }
    validateFrontDoorVerification(props.frontDoorVerification);
    return decision;
  }
  if (decision === AppTheoryMcpOriginReachability.LOCKED) {
    if (props.api !== undefined) {
      throw new Error(
        "AppTheoryMcpServer: originReachability LOCKED is unsupported in attach mode; an API owned outside the construct carries no in-stack mutual-TLS mapping evidence",
      );
    }
    if (owned.domain === undefined) {
      throw new Error(
        "AppTheoryMcpServer: originReachability LOCKED requires an effective ownedApi.domain with mutualTlsAuthentication",
      );
    }
    if (mutualTls === undefined) {
      throw new Error(
        "AppTheoryMcpServer: originReachability LOCKED requires ownedApi.domain.mutualTlsAuthentication; disablement alone is the DISABLED posture",
      );
    }
    return decision;
  }
  if (props.api !== undefined) {
    if (!(props.api instanceof apigwv2.HttpApi)) {
      throw new Error(
        "AppTheoryMcpServer: originReachability DISABLED in attach mode requires a same-stack concrete HttpApi; an imported API exposes no DisableExecuteApiEndpoint evidence",
      );
    }
    registerAttachDisabledOriginValidation(scope, props.api);
    return decision;
  }
  if (owned.domain === undefined) {
    throw new Error(
      "AppTheoryMcpServer: originReachability DISABLED requires an effective ownedApi.domain; the disabled execute-api endpoint is never a public authority",
    );
  }
  return decision;
}

/**
 * Validate the `frontDoorVerification` declaration for `originReachability:
 * FRONTED`.
 *
 * The declaration is mandatory and every field is checked: an absent
 * declaration, a missing or reserved header name, a secret outside the
 * header-value-safe alphabet, and a missing `asserted: true` all fail synthesis
 * rather than producing a declaration the runtime could not honor.
 */
function validateFrontDoorVerification(
  verification: AppTheoryMcpFrontDoorVerificationOptions | undefined,
): void {
  if (verification === undefined) {
    throw new Error(
      "AppTheoryMcpServer: originReachability FRONTED requires frontDoorVerification; the runtime cannot enforce an undeclared front door",
    );
  }
  const headerName = verification.headerName;
  if (typeof headerName !== "string" || !FRONT_DOOR_HEADER_NAME_PATTERN.test(headerName)) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification.headerName must be 1 to 64 characters of [A-Za-z0-9-]",
    );
  }
  const normalizedHeader = headerName.toLowerCase();
  if (
    RESERVED_FRONT_DOOR_HEADERS.has(normalizedHeader)
    || normalizedHeader.startsWith("x-amz-")
    || normalizedHeader.startsWith("x-amzn-")
    || normalizedHeader.startsWith("cloudfront-")
  ) {
    throw new Error(
      `AppTheoryMcpServer: frontDoorVerification.headerName ${headerName} is a reserved or platform-managed request header and cannot carry the front-door verification`,
    );
  }
  const secretValue = verification.secretValue;
  const secretParameterName = verification.secretParameterName;
  const hasLiteral = secretValue !== undefined;
  const hasParameter = secretParameterName !== undefined;
  if (hasLiteral === hasParameter) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification requires exactly one of secretValue and secretParameterName; supply the literal, or the well-known parameter name the application's installer creates",
    );
  }
  if (hasLiteral) {
    if (typeof secretValue !== "string" || !FRONT_DOOR_SECRET_PATTERN.test(secretValue)) {
      throw new Error(
        "AppTheoryMcpServer: frontDoorVerification.secretValue must be 32 to 128 characters of [A-Za-z0-9._~-]",
      );
    }
  } else {
    validateFrontDoorParameterName(secretParameterName);
  }
  if (verification.secretParameterKmsKey !== undefined && !hasParameter) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification.secretParameterKmsKey is only valid with secretParameterName",
    );
  }
  if (verification.asserted !== true) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification requires asserted: true — the caller must record that the runtime verifies the front-door header on every derived route",
    );
  }
}

/**
 * Validate a well-known front-door parameter name.
 *
 * The name must be expressible in a CloudFormation `ssm` dynamic reference and
 * acceptable to Parameter Store, because the construct renders the reference and
 * grants on the ARN. A name outside either contract would fail at deploy time,
 * so it fails synthesis instead.
 */
function validateFrontDoorParameterName(name: string | undefined): void {
  if (
    typeof name !== "string"
    || name.length > FRONT_DOOR_PARAMETER_NAME_MAX_LENGTH
    || !FRONT_DOOR_PARAMETER_NAME_PATTERN.test(name)
    || name.endsWith("/")
    || name.includes("//")
  ) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification.secretParameterName must be a fully qualified SSM parameter name from '/', at most 1011 characters, of [A-Za-z0-9_.-/] with no empty segment",
    );
  }
  const levels = name.split("/").filter((segment) => segment.length > 0);
  const first = levels[0]?.toLowerCase();
  if (levels.length === 0 || levels.length > FRONT_DOOR_PARAMETER_NAME_MAX_LEVELS) {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification.secretParameterName must have between one and fifteen hierarchy levels",
    );
  }
  if (first === "aws" || first === "ssm") {
    throw new Error(
      "AppTheoryMcpServer: frontDoorVerification.secretParameterName must not use the reserved aws or ssm hierarchy",
    );
  }
}

/**
 * The origin custom header the app-owned front door must send.
 *
 * The parameter form renders the CloudFormation dynamic reference the
 * distribution property accepts, so the value is resolved by CloudFormation at
 * stack create/update time and never appears in the application source or this
 * construct's template.
 */
function frontDoorOriginHeader(
  verification: AppTheoryMcpFrontDoorVerificationOptions | undefined,
): AppTheoryMcpFrontDoorHeader {
  if (verification === undefined) {
    throw new Error(
      "AppTheoryMcpServer: originReachability FRONTED requires frontDoorVerification; the runtime cannot enforce an undeclared front door",
    );
  }
  const headerValue = verification.secretParameterName !== undefined
    ? `{{resolve:ssm:${verification.secretParameterName}}}`
    : String(verification.secretValue);
  return { headerName: verification.headerName, headerValue };
}

/**
 * Grant the runtime function read access to the well-known front-door parameter.
 *
 * Parameter Store resolves the distribution's dynamic reference with the
 * deploying principal's permissions, so this grant serves the runtime's lazy
 * read: `ssm:GetParameter` on exactly that parameter ARN (never a wildcard) and,
 * for a SecureString, `kms:Decrypt` on the declared key. Parameter Store needs
 * no KMS permission for a String parameter, which is the type FRONTED requires.
 */
function grantFrontDoorParameterRead(
  scope: Construct,
  handler: lambda.IFunction,
  verification: AppTheoryMcpFrontDoorVerificationOptions | undefined,
): void {
  const parameterName = verification?.secretParameterName;
  if (parameterName === undefined) {
    return;
  }
  handler.addToRolePolicy(new iam.PolicyStatement({
    actions: ["ssm:GetParameter"],
    resources: [
      Stack.of(scope).formatArn({
        service: "ssm",
        resource: "parameter",
        resourceName: parameterName.replace(/^\/+/, ""),
      }),
    ],
  }));
  if (verification?.secretParameterKmsKey !== undefined) {
    verification.secretParameterKmsKey.grantDecrypt(handler);
  }
}

/**
 * The FRONTED fields of the `apptheory:mcp-transport-posture` marker.
 *
 * The literal form records the posture, the header name and a SHA-256 digest of
 * the declared secret, exactly as v7.3 did; the literal is consumed for its
 * digest only, so it never lands in the synthesized template or in
 * CloudFormation. The parameter form records the well-known parameter name and
 * that the value is parameter-sourced instead of a digest, because there is no
 * literal in the application to digest.
 */
function frontDoorPostureMetadata(
  verification: AppTheoryMcpFrontDoorVerificationOptions | undefined,
): Record<string, string> {
  if (verification === undefined) {
    throw new Error(
      "AppTheoryMcpServer: originReachability FRONTED requires frontDoorVerification; the runtime cannot enforce an undeclared front door",
    );
  }
  if (verification.secretParameterName !== undefined) {
    return {
      origin_reachability: AppTheoryMcpOriginReachability.FRONTED,
      front_door_header_name: verification.headerName,
      front_door_secret_source: "ssm-parameter",
      front_door_secret_parameter_name: verification.secretParameterName,
    };
  }
  return {
    origin_reachability: AppTheoryMcpOriginReachability.FRONTED,
    front_door_header_name: verification.headerName,
    front_door_secret_sha256: createHash("sha256").update(String(verification.secretValue), "utf8").digest("hex"),
  };
}

/**
 * Final synthesis proof for an owned DISABLED API: the default execute-api
 * endpoint must still be disabled in the emitted template, even if a later L1
 * override tries to re-enable it.
 */
function registerOwnedDisabledOriginValidation(
  scope: Construct,
  api: apigwv2.HttpApi,
): void {
  const stack = Stack.of(scope);
  const cfnApi = api.node.defaultChild as apigwv2.CfnApi;
  stack.node.addValidation({
    validate: () => {
      if (stack.resolve(cfnApi.disableExecuteApiEndpoint) === true) {
        return [];
      }
      return [
        "AppTheoryMcpServer: originReachability DISABLED requires AWS::ApiGatewayV2::Api.Properties.DisableExecuteApiEndpoint to resolve to true",
      ];
    },
  });
}

/**
 * Final whole-stack proof for an owned LOCKED API.
 *
 * LOCKED is not an alias of DISABLED: at final synthesis the default endpoint
 * must still be disabled and every `CfnApiMapping` bound to the owned API,
 * including mappings another scope adds after construction, must resolve to an
 * in-stack `CfnDomainName` whose `MutualTlsAuthentication` carries a truststore
 * URI. An unresolvable mapping or domain fails closed instead of counting as
 * evidence.
 */
function registerOwnedLockedOriginValidation(
  scope: Construct,
  api: apigwv2.HttpApi,
): void {
  const stack = Stack.of(scope);
  const cfnApi = api.node.defaultChild as apigwv2.CfnApi;
  stack.node.addValidation({
    validate: () => {
      const errors: string[] = [];
      if (stack.resolve(cfnApi.disableExecuteApiEndpoint) !== true) {
        errors.push(
          "AppTheoryMcpServer: originReachability LOCKED requires AWS::ApiGatewayV2::Api.Properties.DisableExecuteApiEndpoint to resolve to true",
        );
      }
      const mappings = cfnApiMappingsBoundToApi(scope, api);
      if (mappings.length === 0) {
        errors.push(
          "AppTheoryMcpServer: originReachability LOCKED requires at least one AWS::ApiGatewayV2::ApiMapping bound to the owned API",
        );
      }
      const domains = cfnDomainNames(scope);
      for (const mapping of mappings) {
        const domain = domains.find(
          (candidate) => comparableApiId(scope, candidate.ref)
            === comparableApiId(scope, mapping.domainName),
        );
        if (domain === undefined) {
          errors.push(
            `AppTheoryMcpServer: originReachability LOCKED cannot resolve mapping ${mapping.node.path} to an in-stack AWS::ApiGatewayV2::DomainName; mutual-TLS evidence is unverifiable`,
          );
          continue;
        }
        if (!hasTruststoreUri(stack, domain)) {
          errors.push(
            `AppTheoryMcpServer: originReachability LOCKED requires every mapping to target a domain with MutualTlsAuthentication.TruststoreUri (${mapping.node.path} -> ${domain.node.path})`,
          );
        }
      }
      return errors;
    },
  });
}

function hasTruststoreUri(stack: Stack, domain: apigwv2.CfnDomainName): boolean {
  const resolved = stack.resolve(domain.mutualTlsAuthentication);
  if (resolved === undefined || resolved === null || typeof resolved !== "object") {
    return false;
  }
  const authentication = resolved as Record<string, unknown>;
  const truststoreUri = authentication.truststoreUri ?? authentication.TruststoreUri;
  return truststoreUri !== undefined && truststoreUri !== null && truststoreUri !== "";
}

/** Every in-stack `CfnApiMapping` whose resolved `ApiId` is the supplied API. */
function cfnApiMappingsBoundToApi(
  scope: Construct,
  api: apigwv2.IHttpApi,
): apigwv2.CfnApiMapping[] {
  const stack = Stack.of(scope);
  const apiKey = comparableApiId(scope, api.apiId);
  const found: apigwv2.CfnApiMapping[] = [];
  const visit = (node: Construct): void => {
    if (node instanceof apigwv2.CfnApiMapping && comparableApiId(scope, node.apiId) === apiKey) {
      found.push(node);
    }
    for (const child of node.node.children) {
      visit(child);
    }
  };
  visit(stack);
  return found;
}

function cfnDomainNames(scope: Construct): apigwv2.CfnDomainName[] {
  const stack = Stack.of(scope);
  const found: apigwv2.CfnDomainName[] = [];
  const visit = (node: Construct): void => {
    if (node instanceof apigwv2.CfnDomainName) {
      found.push(node);
    }
    for (const child of node.node.children) {
      visit(child);
    }
  };
  visit(stack);
  return found;
}

/**
 * Final synthesis proof for an attach DISABLED declaration: the concrete API
 * must bind to exactly one in-stack CfnApi whose DisableExecuteApiEndpoint
 * resolves to literal true. The construct never mutates the attached API.
 */
function registerAttachDisabledOriginValidation(
  scope: Construct,
  api: apigwv2.IHttpApi,
): void {
  const stack = Stack.of(scope);
  stack.node.addValidation({
    validate: () => {
      const cfnApis = cfnApisBoundToApi(scope, api);
      if (cfnApis.length !== 1) {
        return [
          "AppTheoryMcpServer: originReachability DISABLED in attach mode requires exactly one same-stack AWS::ApiGatewayV2::Api; the attached API's DisableExecuteApiEndpoint cannot be proven",
        ];
      }
      if (stack.resolve(cfnApis[0].disableExecuteApiEndpoint) !== true) {
        return [
          "AppTheoryMcpServer: originReachability DISABLED in attach mode requires the attached AWS::ApiGatewayV2::Api to set DisableExecuteApiEndpoint=true",
        ];
      }
      return [];
    },
  });
}

/** Every in-stack `CfnApi` whose `Ref` is the supplied API's id. */
function cfnApisBoundToApi(scope: Construct, api: apigwv2.IHttpApi): apigwv2.CfnApi[] {
  const stack = Stack.of(scope);
  const apiKey = comparableApiId(scope, api.apiId);
  const found: apigwv2.CfnApi[] = [];
  const visit = (node: Construct): void => {
    if (node instanceof apigwv2.CfnApi && comparableApiId(scope, node.ref) === apiKey) {
      found.push(node);
    }
    for (const child of node.node.children) {
      visit(child);
    }
  };
  visit(stack);
  return found;
}

function validateOwningApiDefense(
  defense: AppTheoryMcpOwningApiDefenseOptions | undefined,
  label: string,
): void {
  if (defense === undefined) {
    throw new Error(
      `AppTheoryMcpServer: transportPosture ${label} requires owningApiDefense to record the owning API's access logging and throttling decisions`,
    );
  }
  if (defense.accessLogging !== true) {
    throw new Error(
      `AppTheoryMcpServer: transportPosture ${label} requires owningApiDefense.accessLogging to be true`,
    );
  }
  const throttling: Partial<AppTheoryMcpOwningApiThrottlingOptions> | undefined = defense.throttling;
  const rateLimit = throttling?.rateLimit;
  const burstLimit = throttling?.burstLimit;
  if (
    !Number.isFinite(rateLimit)
    || (rateLimit as number) <= 0
    || !Number.isFinite(burstLimit)
    || (burstLimit as number) <= 0
  ) {
    throw new Error(
      `AppTheoryMcpServer: transportPosture ${label} requires owningApiDefense.throttling rateLimit and burstLimit to be positive finite numbers`,
    );
  }
}

function validateDenialSignal(signal?: AppTheoryMcpDenialSignalOptions): void {
  if (signal === undefined) {
    throw new Error(
      "AppTheoryMcpServer: transportPosture RUNTIME_BEARER requires denialSignal",
    );
  }
  if (signal.metricName !== undefined && signal.metricName !== MCP_DENIAL_METRIC_NAME) {
    throw new Error(
      `AppTheoryMcpServer: denialSignal.metricName must be ${MCP_DENIAL_METRIC_NAME}`,
    );
  }
  if (signal.dimensions !== undefined) {
    const dimensions = Array.isArray(signal.dimensions) ? signal.dimensions : [];
    const bounded = dimensions.length === MCP_DENIAL_DIMENSIONS.length
      && MCP_DENIAL_DIMENSIONS.every(
        (dimension) => dimensions.filter((value) => value === dimension).length === 1,
      );
    if (!bounded) {
      throw new Error(
        `AppTheoryMcpServer: denialSignal.dimensions must be exactly ${JSON.stringify(MCP_DENIAL_DIMENSIONS)}`,
      );
    }
  }
}

function validateLiteralOAuthURL(value: string, allowQuery: boolean, message: string): void {
  const literal = value.trim();
  let parsed: URL | undefined;
  try {
    parsed = new URL(literal);
  } catch {
    // The shared validation error below is the public synthesis contract.
  }
  if (
    !parsed
    || !literalURLHasRFC3986Authority(literal)
    || parsed.protocol !== "https:"
    || !parsed.hostname
    || parsed.username !== ""
    || parsed.password !== ""
    || literalURLAuthorityHasUserinfo(literal)
    || (!allowQuery && literal.includes("?"))
    || literal.includes("#")
  ) {
    throw new Error(`AppTheoryMcpServer: ${message}`);
  }
}

function toHttpMethod(method: string): apigwv2.HttpMethod {
  switch (method) {
    case "POST": return apigwv2.HttpMethod.POST;
    case "GET": return apigwv2.HttpMethod.GET;
    case "DELETE": return apigwv2.HttpMethod.DELETE;
    default:
      throw new Error(`AppTheoryMcpServer: unsupported runtime MCP method ${method}`);
  }
}

function validatePositiveNumber(value: number, propName: string): void {
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`AppTheoryMcpServer: ${propName} must be greater than zero`);
  }
}

function validatePositiveInteger(value: number, propName: string): void {
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`AppTheoryMcpServer: ${propName} must be a positive integer`);
  }
}

function accessLogFormat(): string {
  return JSON.stringify({
    requestId: "$context.requestId",
    ip: "$context.identity.sourceIp",
    requestTime: "$context.requestTime",
    httpMethod: "$context.httpMethod",
    routeKey: "$context.routeKey",
    status: "$context.status",
    protocol: "$context.protocol",
    responseLength: "$context.responseLength",
    integrationLatency: "$context.integrationLatency",
  });
}

function toRoute53RecordName(domainName: string, zone: route53.IHostedZone): string {
  const fqdn = String(domainName ?? "").trim().replace(/\.$/, "");
  const zoneName = String(zone.zoneName ?? "").trim().replace(/\.$/, "");
  if (!zoneName) return fqdn;
  if (fqdn === zoneName) return "";
  const suffix = `.${zoneName}`;
  return fqdn.endsWith(suffix) ? fqdn.slice(0, -suffix.length) : fqdn;
}

function stripTrailingSlash(url: string): string {
  return url.replace(/\/$/, "");
}

function literalURLHasRFC3986Authority(value: string): boolean {
  const authority = /^https:\/\/([^/?#]+)(?:[/?#]|$)/i.exec(value)?.[1];
  return authority !== undefined && !authority.includes("%");
}

function literalURLAuthorityHasUserinfo(value: string): boolean {
  const authority = /^[A-Za-z][A-Za-z0-9+.-]*:\/\/([^/?#]*)/.exec(value)?.[1];
  return authority?.includes("@") ?? false;
}
